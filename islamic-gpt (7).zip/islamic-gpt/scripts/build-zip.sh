#!/bin/bash
# Rebuild islamic-gpt.zip — clean, portable, deployment-ready package
set -e
cd /home/z/my-project

ZIP=download/islamic-gpt.zip
STAGE=/tmp/islamic-gpt-pkg

rm -rf "$STAGE" "$ZIP"
mkdir -p "$STAGE/islamic-gpt"

# --- app code & config ---
cp -r src "$STAGE/islamic-gpt/src"
cp -r prisma "$STAGE/islamic-gpt/prisma"
cp -r scripts "$STAGE/islamic-gpt/scripts"
cp -r public "$STAGE/islamic-gpt/public"
cp -r data-src "$STAGE/islamic-gpt/data-src" 2>/dev/null || true
cp -r deploy "$STAGE/islamic-gpt/deploy"
cp -r db "$STAGE/islamic-gpt/db"
cp package.json bun.lock tsconfig.json next.config.ts tailwind.config.ts \
   postcss.config.mjs eslint.config.mjs components.json README.md \
   "$STAGE/islamic-gpt/" 2>/dev/null || true

# --- deployment files ---
cp Dockerfile .dockerignore render.yaml "$STAGE/islamic-gpt/"

# --- portable .env (relative path) ---
cat > "$STAGE/islamic-gpt/.env" <<'EOF'
DATABASE_URL=file:../db/custom.db
EOF
cp .env.example "$STAGE/islamic-gpt/.env.example" 2>/dev/null || true

# --- remove test logs from src copy if any ---
find "$STAGE" -name "*.log" -delete

# --- zip it ---
cd "$STAGE"
zip -rq /home/z/my-project/$ZIP islamic-gpt
cd /home/z/my-project

echo "== ZIP built =="
ls -lh "$ZIP"
echo "== file count: $(unzip -l $ZIP | tail -1) =="
echo "== key files check =="
unzip -l "$ZIP" | rg -i "Dockerfile|dockerignore|render.yaml|instrumentation|README-DEPLOY|hf-space" || echo "MISSING DEPLOY FILES!"
