/**
 * تهيئة قاعدة البيانات تلقائياً — تعمل على Vercel أثناء البناء وعلى أي جهاز
 *
 * تعمل بثلاث خطوات آمنة وقابلة للتكرار (idempotent):
 *   1) إنشاء الجداول إن لم تكن موجودة (من deploy/turso-schema.sql)
 *   2) زرع القرآن الكريم كاملاً (١١٤ سورة، ٦٢٣٦ آية) إن كانت القاعدة فارغة
 *   3) إنشاء حساب الإدارة + الحساب التجريبي + طلبات الاشتراك التجريبية
 *
 * إذا لم يوجد TURSO_DATABASE_URL: تخرج بنجاح بدون فعل شيء (وضع SQLite المحلي)
 * إذا كانت القاعدة مزروعة مسبقاً: تخرج بنجاح بدون مساس بالبيانات
 *
 * التشغيل اليدوي:
 *   TURSO_DATABASE_URL=libsql://... TURSO_AUTH_TOKEN=... node scripts/apply-turso.mjs
 */
import { createClient } from "@libsql/client";
import { readFileSync } from "fs";
import { randomBytes, scryptSync } from "crypto";
import { fileURLToPath } from "url";
import path from "path";

const ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), "..");

const url = process.env.TURSO_DATABASE_URL;
const token = process.env.TURSO_AUTH_TOKEN;

if (!url) {
  console.log("[apply-turso] لا يوجد TURSO_DATABASE_URL — وضع SQLite المحلي، لا شيء مطلوب");
  process.exit(0);
}

const db = createClient({ url, authToken: token || undefined });

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `s2$${salt}$${hash}`;
}

// ---------- تنقية نصوص القرآن (نفس منطق seed.ts) ----------
const DIACRITICS = /[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]/g;
function normBasic(s) {
  return s
    .replace(/[\ufeff\u200f\u200e]/g, "")
    .replace(DIACRITICS, "")
    .replace(/[\u0622\u0623\u0625\u0671]/g, "\u0627")
    .replace(/\u0640/g, "");
}
const BISMILLAH_NORM = normBasic("بسم الله الرحمن الرحيم");

function stripLeadingBismillah(text) {
  let norm = "";
  const map = [];
  for (let i = 0; i < text.length; i++) {
    const ch = text[i];
    if (/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]/.test(ch)) continue;
    const mapped = normBasic(ch);
    norm += mapped;
    for (let k = 0; k < mapped.length; k++) map.push(i);
  }
  if (!norm.startsWith(BISMILLAH_NORM)) return text;
  const cutAfter = map[BISMILLAH_NORM.length - 1] + 1;
  return text
    .slice(cutAfter)
    .replace(/^[\s\u00A0\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]+/, "");
}

async function main() {
  // ---------- ١) هل القاعدة مزروعة مسبقاً؟ ----------
  try {
    const users = await db.execute("SELECT COUNT(*) AS c FROM User");
    if (Number(users.rows[0].c) > 0) {
      console.log(`[apply-turso] القاعدة مزروعة مسبقاً (${users.rows[0].c} مستخدم) — تخطي`);
      process.exit(0);
    }
  } catch {
    // جدول User غير موجود → متابعة الإنشاء
  }

  // ---------- ٢) إنشاء الجداول ----------
  console.log("[apply-turso] … إنشاء الجداول");
  const schemaSql = readFileSync(path.join(ROOT, "deploy", "turso-schema.sql"), "utf-8");
  await db.executeMultiple(schemaSql);
  console.log("[apply-turso] ✓ 7 جداول جاهزة");

  // ---------- ٣) زرع القرآن ----------
  console.log("[apply-turso] … زرع القرآن الكريم");
  const raw = JSON.parse(readFileSync(path.join(ROOT, "data-src", "quran-uthmani.json"), "utf-8"));
  const surahs = raw.data.surahs;

  let ayahCount = 0;
  for (const s of surahs) {
    const cleanName = s.name.replace(/^سُورَةُ\s*/, "").trim();
    await db.execute({
      sql: `INSERT INTO Surah (number, name, englishName, englishTranslation, revelationType, numberOfAyahs)
            VALUES (?, ?, ?, ?, ?, ?)`,
      args: [s.number, cleanName, s.englishName, s.englishNameTranslation,
             s.revelationType === "Meccan" ? "مكية" : "مدنية", s.ayahs.length],
    });

    const stmts = [];
    for (const a of s.ayahs) {
      let text = a.text.replace(/[\ufeff\u200f\u200e]/g, "").trim();
      if (s.number !== 1 && s.number !== 9 && a.numberInSurah === 1) {
        text = stripLeadingBismillah(text);
      }
      stmts.push({
        sql: `INSERT INTO Ayah (surahNumber, numberInSurah, text) VALUES (?, ?, ?)`,
        args: [s.number, a.numberInSurah, text],
      });
      ayahCount++;
      if (stmts.length >= 300) {
        await db.batch(stmts, "write");
        stmts.length = 0;
      }
    }
    if (stmts.length) await db.batch(stmts, "write");
  }
  console.log(`[apply-turso] ✓ القرآن: ${surahs.length} سورة، ${ayahCount} آية`);

  // ---------- ٤) الحسابات والطلبات التجريبية ----------
  console.log("[apply-turso] … إنشاء الحسابات");
  const now = new Date().toISOString().replace("T", " ").slice(0, 19);
  const pw = hashPassword("islamicgpt333434");

  await db.batch([
    { sql: `INSERT INTO User (id, email, passwordHash, name, role, plan, wordBalance, freeMessagesUsed, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: ["u-admin-" + randomBytes(6).toString("hex"), "admin@islamicgpt.com", pw,
             "مدير الموقع", "ADMIN", "WORDS_1500", 1500, 0, now, now] },
    { sql: `INSERT INTO User (id, email, passwordHash, name, role, plan, wordBalance, freeMessagesUsed, createdAt, updatedAt)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      args: ["u-user-" + randomBytes(6).toString("hex"), "user@test.com", pw,
             "أحمد التجريبي", "USER", "FREE", 0, 0, now, now] },
    { sql: `INSERT INTO SubscriptionRequest (id, userId, planId, userName, phone, paymentMethod, transactionRef, status, amount, words, createdAt)
            SELECT ?, id, ?, ?, ?, ?, ?, ?, ?, ?, ? FROM User WHERE email = ?`,
      args: ["sr-pending-1", "WORDS_500", "أحمد التجريبي", "01012345678", "vodafone_cash",
             "TX-DEMO-12345", "PENDING", 50, 500, now, "user@test.com"] },
    { sql: `INSERT INTO SubscriptionRequest (id, userId, planId, userName, phone, paymentMethod, transactionRef, status, amount, words, createdAt, reviewedAt, adminNote)
            SELECT ?, id, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ? FROM User WHERE email = ?`,
      args: ["sr-approved-1", "WORDS_1500", "أحمد التجريبي", "01012345678", "instapay",
             "TX-DEMO-99999", "APPROVED", 100, 1500, now, now, "تم التحقق من التحويل", "user@test.com"] },
    { sql: `INSERT INTO Subscription (id, userId, planId, wordsGranted, requestId, active, createdAt)
            SELECT ?, id, ?, ?, NULL, 1, ? FROM User WHERE email = ?`,
      args: ["sub-1", "WORDS_1500", 0, now, "user@test.com"] },
  ], "write");
  console.log("[apply-turso] ✓ admin@islamicgpt.com + user@test.com (كلمة المرور islamicgpt333434)");

  console.log("[apply-turso] ✅ اكتملت تهيئة قاعدة البيانات");
}

main().catch((e) => {
  console.error("[apply-turso] ❌ فشل:", e?.message ?? e);
  process.exit(1);
});
