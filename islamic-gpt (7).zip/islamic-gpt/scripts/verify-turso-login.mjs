// تحقق نهائي: تسجيل دخول على قاعدة مزروعة عبر apply-turso (نفس منطق auth.ts)
import { createClient } from "@libsql/client";
import { PrismaLibSQL } from "@prisma/adapter-libsql";
import { PrismaClient } from "@prisma/client";
import { scryptSync, timingSafeEqual } from "crypto";

function verifyPassword(password, stored) {
  try {
    const [, salt, hash] = stored.split("$");
    if (!salt || !hash) return false;
    const candidate = scryptSync(password, salt, 64);
    const expected = Buffer.from(hash, "hex");
    return candidate.length === expected.length && timingSafeEqual(candidate, expected);
  } catch {
    return false;
  }
}

const adapter = new PrismaLibSQL({
  url: process.env.TURSO_DATABASE_URL,
  authToken: process.env.TURSO_AUTH_TOKEN || undefined,
});
const db = new PrismaClient({ adapter });

const admin = await db.user.findUnique({ where: { email: "admin@islamicgpt.com" } });
const user = await db.user.findUnique({ where: { email: "user@test.com" } });

console.log("admin exists:", !!admin, "| role:", admin?.role, "| login:", verifyPassword("islamicgpt333434", admin?.passwordHash ?? ""));
console.log("user exists:", !!user, "| plan:", user?.plan, "| login:", verifyPassword("islamicgpt333434", user?.passwordHash ?? ""));
console.log("wrong password rejected:", verifyPassword("wrongpass", user?.passwordHash ?? "") === false);

const surahs = await db.surah.count();
const ayahs = await db.ayah.count();
const reqs = await db.subscriptionRequest.count();
console.log(`surahs: ${surahs} | ayahs: ${ayahs} | subscriptionRequests: ${reqs}`);
await db.$disconnect();
