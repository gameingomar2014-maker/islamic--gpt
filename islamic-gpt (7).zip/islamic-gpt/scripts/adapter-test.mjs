import { createClient } from "@libsql/client";
import { PrismaLibSQL } from "@prisma/adapter-libsql";
import { PrismaClient } from "@prisma/client";

console.log("1) libsql client direct query...");
const libsql = createClient({ url: process.env.TURSO_DATABASE_URL });
const r = await libsql.execute("SELECT COUNT(*) as c FROM User");
console.log("   ✓ users:", r.rows[0].c);

console.log("2) PrismaLibSQL adapter...");
const adapter = new PrismaLibSQL(libsql);
console.log("   ✓ adapter created");

console.log("3) PrismaClient with adapter...");
const db = new PrismaClient({ adapter });
const users = await db.user.findMany({ take: 2 });
console.log("   ✓ prisma users:", users.length, users.map((u) => u.email));
await db.$disconnect();
