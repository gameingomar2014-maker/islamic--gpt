import ZAI from 'z-ai-web-dev-sdk';

async function main() {
  try {
    const zai = await ZAI.create();
    const completion = await zai.chat.completions.create({
      messages: [
        { role: 'system', content: 'أنت مساعد إسلامي. أجب بسطر واحد فقط.' },
        { role: 'user', content: 'كم عدد سور القرآن؟' },
      ],
      thinking: { type: 'disabled' },
    });
    const content = completion.choices[0]?.message?.content;
    console.log('AI_OK:', content);
  } catch (e) {
    console.error('AI_ERROR:', e instanceof Error ? e.message : String(e));
  }
}
main();
