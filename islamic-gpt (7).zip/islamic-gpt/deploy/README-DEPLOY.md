# 🚀 دليل نشر Islamic GPT مجاناً

## ⚡ تحديث مهم: Vercel الآن يعمل! (بقاعدة Turso)

**سبب رسالة "خطأ اتصال" عند تسجيل الدخول على Vercel:** قاعدة البيانات كانت SQLite
ملف محلي، وسيرفرات Vercel **قراءة فقط (Read-Only)** — فأي عملية دخول تفشل لأن
قاعدة البيانات لا تستطيع فتح ملفها. الحل: نقل قاعدة البيانات إلى **Turso** —
قاعدة SQLite في السحابة، خطة مجانية سخية، ونفس الكود يعمل بدون تعديل المخطط.

### خطوات Vercel + Turso (≈ 10 دقائق — بدون تشغيل أي سكريبت على جهازك)

> ✨ **ميزة جديدة**: أثناء البناء على Vercel يزرع المشروع القرآن كاملاً والحسابات
> في قاعدة Turso **تلقائياً** — لن تحتاج تشغيل أي أمر محلياً.

**١) أنشئ قاعدة Turso واحصل على بيانات الاتصال:**

الطريقة الأسهل (سطر أوامر على جهازك):
```bash
curl -sSfL https://get.tur.so/install.sh | bash    # لينكس/ماك
# ويندوز (PowerShell): iwr https://get.tur.so/install.ps1 -useb | iex

turso auth login              # سجّل دخولك بحساب GitHub
turso db create islamic-gpt
turso db show islamic-gpt --url        # ← انسخ الرابط libsql://...
turso db tokens create islamic-gpt     # ← انسخ الرمز
```
(بديل بدون تثبيت: من موقع **app.turso.tech** أنشئ قاعدة ثم انسخ الـ URL والرمز من صفحة القاعدة)

**٢) ارفع المجلد على Vercel** (نفس ما تفعله الآن — Next.js) — سينجح النشر
لكن تسجيل الدخول لن يعمل بعد، لأن المتغيرات لم تُضف بعد.

**٣) أضف متغيرات البيئة** من **Project → Settings → Environment Variables**:

| الاسم | القيمة |
|---|---|
| `TURSO_DATABASE_URL` | `libsql://islamic-gpt-xxx.turso.io` |
| `TURSO_AUTH_TOKEN` | الرمز من خطوة ١ |
| `AUTH_SECRET` | أي نص عشوائي طويل |
| `ZAI_API_KEY` | مفتاحك من z.ai (خطوات الحصول عليه بالأسفل) |
| `ZAI_BASE_URL` | `https://api.z.ai/api/paas/v4` |
| `ZAI_MODEL` | `glm-4.5-flash` (مجاني) أو `glm-4.6` (أجود) |

**٤) اعمل Redeploy** من تبويب **Deployments** → اضغط على آخر نشر → القائمة (⋮) → **Redeploy**

**٥) تحقق من النجاح**: في سجل البناء (Building) سترى:
```
[apply-turso] ✓ القرآن: 114 سورة، 6236 آية
[apply-turso] ✓ admin@islamicgpt.com + user@test.com
```
✅ بعدها تسجيل الدخول يعمل، وكل البيانات تُحفظ دائماً.

> 🔧 **إذا لم تظهر رسالة الزرع في اللوج**: اذهب إلى
> Settings → General → Build & Output Settings → عطّل Override تلقائي وضبط
> Build Command يدوياً إلى:
> `node scripts/apply-turso.mjs && next build`
> ثم Redeploy مرة أخرى. (الزرع آمن للتكرار — لن يمسح بيانات موجودة)

> ملاحظة: احذف أي `DATABASE_URL` قديم من متغيرات Vercel إن كنت أضفته سابقاً.

---

## أولاً: لماذا كان Vercel يفشل سابقاً؟

ثلاثة أسباب جوهرية كانت تجعل Vercel يفشل — **وكلها مُصلَحة الآن**:

1. **سكريبت البناء لم يكن يولّد عميل Prisma** — أُضيف `prisma generate` إلى البناء و `postinstall`.
2. **قاعدة البيانات SQLite ملف على قرص قراءة فقط** — حُلّت نهائياً بالدعم المدمج لـ **Turso** في `src/lib/db.ts`: عندما تضع `TURSO_DATABASE_URL` يتصل التطبيق بقاعدة Turso السحابية تلقائياً.
3. **إعدادات الذكاء الاصطناعي** — العميل الجديد `src/lib/zai.ts` يقرأ `ZAI_API_KEY` من متغيرات البيئة مباشرة بدون أي ملف.

الخلاصة: **Vercel + Turso = يعمل بالكامل** (انظر الخطوات أعلاه)، أو استخدم الخيارات التالية للبقاء على SQLite الملفي.

---

## ثانياً: تجهيز مفتاح الذكاء الاصطناعي (خطوة مشتركة لكل الخيارات)

المحادثة الذكية تعتمد على واجهة Z.ai. على أي سيرفر خارجي تحتاج مفتاحك الخاص:

1. سجّل حساباً في منصة **z.ai** (أو open.bigmodel.cn للاستخدام من الصين)
2. اذهب إلى **API Keys** وأنشئ مفتاحاً جديداً وانسخه
3. ستحتاج قيمتين:
   - `ZAI_API_KEY` = مفتاحك
   - `ZAI_BASE_URL` = `https://api.z.ai/api/paas/v4`
   - `ZAI_MODEL` = `glm-4.5-flash` (مجاني) — اختياري لكن مستحسن على الواجهة العامة

> ملاحظة: إذا لم تضع مفتاحاً، كل الموقع يعمل بشكل كامل (القرآن، الحسابات، الاشتراكات، لوحة الإدارة) وستظهر رسالة خطأ فقط عند المحادثة الذكية.

---

## الخيار 1: Hugging Face Spaces — مجاني 100% وبدون بطاقة ⭐ الأسهل

منصة مجانية تماماً، لا تطلب بطاقة ائتمانية، وتعطيك رابطاً مباشراً: `https://اسم-حسابك-islamic-gpt.hf.space`

### الخطوات

1. أنشئ حساباً في **huggingface.co**
2. من صفحتك: **New → Space**
   - Space name: `islamic-gpt`
   - SDK: اختر **Docker** → Blank
   - Visibility: Public
3. ارفع ملفات المشروع إلى الـ Space بأحد الطريقتين:
   - **بدون أوامر**: من صفحة الـ Space اضغط **Files → Add file → Upload files** وارفع محتويات مجلد المشروع (بدون node_modules و .next) ملفاً ملفاً أو مضغوطة ثم فك الضغط من داخل الـ Space
   - **بأوامر git** (أسرع):
     ```bash
     git clone https://huggingface.co/spaces/اسم-حسابك/islamic-gpt
     cd islamic-gpt
     # انسخ محتويات المشروع هنا
     git add . && git commit -m "deploy" && git push
     ```
4. **مهم**: انسخ محتوى ملف `deploy/hf-space-README.md` إلى ملف `README.md` في جذر الـ Space (يحتوي إعدادات Docker والمنفذ)
5. من **Settings → Variables and secrets** أضف:
   - Secret باسم `ZAI_API_KEY` بقيمة مفتاحك
   - Secret باسم `AUTH_SECRET` بأي نص عشوائي طويل
6. انتظر انتهاء البناء (5–10 دقائق) وسيفتح موقعك مباشرة

### حدود النسخة المجانية

| الميزة | القيمة |
|---|---|
| المعالج والذاكرة | 2 vCPU / 16GB RAM |
| النوم بعد الخمول | 48 ساعة (يستيقظ تلقائياً عند أول زيارة) |
| تخزين البيانات | مؤقت — بيانات SQLite تعود للنسخة الأصلية عند إعادة التشغيل |

> حكم عملي: ممتاز للعرض والتجربة وإظهار الموقع للناس. أما لو عندك اشتراكات حقيقية مدفوعة فاستخدم الخيار 3.

---

## الخيار 2: Render.com — مجاني مع حساب GitHub

### الخطوات

1. ارفع مجلد المشروع إلى مستودع **GitHub** جديد (بدون node_modules و .next)
2. سجّل في **render.com** (يقبل تسجيل الدخول بـ GitHub، بدون بطاقة)
3. من اللوحة: **New → Blueprint** واختر المستودع — سيقرأ ملف `render.yaml` تلقائياً
4. عندما يطلب `ZAI_API_KEY` الصق مفتاحك، ثم اضغط **Apply**
5. بعد 5–10 دقائق يكون موقعك على رابط: `https://islamic-gpt.onrender.com`

### حدود النسخة المجانية

- الموقع ينام بعد 15 دقيقة خمول (أول زيارة بعده تستغرق ~50 ثانية للاستيقاظ)
- التخزين مؤقت كذلك (يفقد تعديلات البيانات عند إعادة النشر)

---

## الخيار 3: Oracle Cloud Always Free — الأقوى والمجاني للأبد 🏆

VPS حقيقي مجاني **للأبد** (وليس تجربة): تختار حتى 4 معالجات ARM و24GB ذاكرة، وقاعدة البيانات والملفات **تُحفظ بشكل دائم** — أنسب حل لموقع به اشتراكات فودافون كاش/إنستاباي.

### الخطوات باختصار

1. سجّل في **oracle.com/cloud/free** (يطلب بطاقة للتحقق فقط — لا يتم خصم أي مبلغ على الخطة المجانية)
2. أنشئ VM: **Compute → Create Instance**
   - Shape: **Ampere A1** (ARM) — 2–4 OCPU
   - System: **Ubuntu 22.04**
   - أضف قاعدة في الشبكة تسمح بالمنفذين 22 و80 و443
3. اتصل بالسيرفر وثبّت الأدوات:
   ```bash
   ssh ubuntu@IP-السيرفر
   curl -fsSL https://bun.sh/install | bash
   sudo apt update && sudo apt install -y nginx
   ```
4. ارفع ملف ZIP (أمر `scp` أو لوحة السحب) ثم:
   ```bash
   unzip islamic-gpt.zip && cd islamic-gpt
   bun install
   bun run build
   ```
5. شغّل الموقع دائماً مع إعادة التشغيل التلقائي:
   ```bash
   sudo tee /etc/systemd/system/islamic-gpt.service > /dev/null <<'EOF'
   [Unit]
   Description=Islamic GPT
   After=network.target
   [Service]
   User=ubuntu
   WorkingDirectory=/home/ubuntu/islamic-gpt
   Environment=NODE_ENV=production
   Environment=AUTH_SECRET=ضع-هنا-نصاً-عشوائياً-طويلاً
   Environment=ZAI_API_KEY=ضع-مفتاحك-هنا
   Environment=ZAI_BASE_URL=https://api.z.ai/api/paas/v4
   ExecStart=/home/ubuntu/.bun/bin/bun run start:node
   Restart=always
   [Install]
   WantedBy=multi-user.target
   EOF
   sudo systemctl enable --now islamic-gpt
   ```
6. اربط الدومين عبر Nginx + شهادة SSL مجانية:
   ```bash
   sudo tee /etc/nginx/sites-available/islamic > /dev/null <<'EOF'
   server {
     listen 80;
     server_name دومينك.com;
     location / {
       proxy_pass http://127.0.0.1:3000;
       proxy_set_header Host $host;
       proxy_set_header X-Real-IP $remote_addr;
     }
   }
   EOF
   sudo ln -s /etc/nginx/sites-available/islamic /etc/nginx/sites-enabled/
   sudo nginx -t && sudo systemctl reload nginx
   sudo apt install -y certbot python3-certbot-nginx
   sudo certbot --nginx -d دومينك.com
   ```

**النتيجة**: موقعك يعمل 24/7 بقاعدة بيانات دائمة، مجاناً للأبد، وتتحكم بكل شيء.

> بديل بنفس الفكرة: أي VPS رخيص (Hostinger/Contabo ~4$/شهر) بنفس خطوات 3–6 بالضبط.

---

## ثالثاً: متغيرات البيئة الكاملة للنشر

| المتغير | ضروري؟ | القيمة |
|---|---|---|
| `TURSO_DATABASE_URL` | على Vercel فقط | `libsql://...` (بدونه يستخدم SQLite الملفي) |
| `TURSO_AUTH_TOKEN` | على Vercel فقط | رمز القاعدة من Turso |
| `DATABASE_URL` | للـ VPS/Docker | `file:/app/db/custom.db` (موجود في Dockerfile) |
| `AUTH_SECRET` | نعم في الإنتاج | نص عشوائي طويل لتوقيع الجلسات |
| `ZAI_API_KEY` | للمحادثة فقط | مفتاحك من z.ai |
| `ZAI_BASE_URL` | للمحادثة فقط | `https://api.z.ai/api/paas/v4` |
| `ZAI_MODEL` | مستحسن على z.ai | `glm-4.5-flash` (مجاني) أو `glm-4.6` |
| `PORT` | تلقائي | المنصات تضبطه، والافتراضي 3000 |

> ملاحظة أمنية مهمة قبل الإطلاق الحقيقي: غيّر كلمة مرور حساب الإدارة من لوحة "حسابي"، ولا تشارك بيانات `db/custom.db` التي تحتوي الحسابات التجريبية مع أحد.

---

## رابعاً: أي خيار أنسب لك؟

| وضعك | الخيار المناسب |
|---|---|
| "عايز Vercel يشتغل خلاص" | **Vercel + Turso** (الخطوات في أول الصفحة) |
| "عايز أوري الناس الموقع شغال" | الخيار 1 — Hugging Face (دقيقتان، بدون بطاقة) |
| "عندي حساب GitHub وأبسط إعداد" | الخيار 2 — Render |
| "الموقع هيقدم اشتراكات مدفوعة فعلاً" | الخيار 3 — Oracle Free VPS (بيانات دائمة) |
