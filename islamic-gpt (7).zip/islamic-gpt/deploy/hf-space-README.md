---
title: Islamic GPT
emoji: 🕌
colorFrom: green
colorTo: purple
sdk: docker
app_port: 3000
pinned: false
---

# Islamic GPT — على Hugging Face Spaces

هذا الملف هو الـ README الخاص بالـ Space (يحتوي إعدادات النشر أعلاه).
انسخ محتوياته إلى ملف `README.md` في جذر مستودع الـ Space.

## الملفات المطلوبة في مستودع الـ Space

كل محتويات مجلد المشروع (بدون node_modules و .next) بالإضافة إلى:

| ملف | الوظيفة |
|---|---|
| `Dockerfile` | بناء وتشغيل الموقع |
| `db/custom.db` | قاعدة البيانات الجاهزة (القرآن + الحسابات) |

## المتغيرات السرية (Settings → Variables and secrets)

| الاسم | القيمة |
|---|---|
| `ZAI_API_KEY` | مفتاح Z.ai API الخاص بك (من z.ai) |
| `ZAI_BASE_URL` | `https://api.z.ai/api/paas/v4` |
| `AUTH_SECRET` | أي نص عشوائي طويل (لتوقيع الجلسات) |

> الفضاء المجاني ينام بعد 48 ساعة خمول، والتخزين مؤقت (بيانات SQLite تُعاد
> إلى نسخة الصورة عند إعادة التشغيل). للاستخدام الفعلي مع اشتراكات مدفوعة
> يُنصح بـ Oracle Cloud Always Free (انظر deploy/README-DEPLOY.md).
