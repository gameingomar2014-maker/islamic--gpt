"use client";

import { useEffect } from "react";
import { useStore, parseHash, Route } from "@/lib/store";
import { AppShell } from "@/components/layout/AppShell";
import { HomeView } from "@/components/views/HomeView";
import { QuranView } from "@/components/views/QuranView";
import { SurahView } from "@/components/views/SurahView";
import { ChatView } from "@/components/views/ChatView";
import { PlansView } from "@/components/views/PlansView";
import { AccountView } from "@/components/views/AccountView";
import { AdminView } from "@/components/views/AdminView";
import { AuthView } from "@/components/views/AuthView";
import { AboutView } from "@/components/views/AboutView";

function CurrentView({ route }: { route: Route }) {
  switch (route.view) {
    case "home":
      return <HomeView />;
    case "quran":
      return <QuranView />;
    case "surah":
      return <SurahView surahNumber={route.n} />;
    case "chat":
      return <ChatView />;
    case "plans":
      return <PlansView />;
    case "account":
      return <AccountView />;
    case "admin":
      return <AdminView />;
    case "login":
      return <AuthView initialMode={route.mode} />;
    case "about":
      return <AboutView />;
    default:
      return <HomeView />;
  }
}

export default function Page() {
  const route = useStore((s) => s.route);
  const setRoute = useStore((s) => s.setRoute);
  const refreshMe = useStore((s) => s.refreshMe);
  const persistPosition = useStore((s) => s.persistPosition);

  useEffect(() => {
    const sync = () => {
      setRoute(parseHash(window.location.hash));
      window.scrollTo({ top: 0 });
    };
    sync();
    window.addEventListener("hashchange", sync);
    const onLeave = () => persistPosition();
    window.addEventListener("beforeunload", onLeave);
    refreshMe();
    return () => {
      window.removeEventListener("hashchange", sync);
      window.removeEventListener("beforeunload", onLeave);
    };
  }, [setRoute, refreshMe, persistPosition]);

  return (
    <AppShell>
      <CurrentView route={route} />
    </AppShell>
  );
}
