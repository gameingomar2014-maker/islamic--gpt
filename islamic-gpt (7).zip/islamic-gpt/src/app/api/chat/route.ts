import { NextResponse } from "next/server";
import { z } from "zod";
import { zai } from "@/lib/zai";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { searchQuran, SearchHit } from "@/lib/quran-search";
import { FREE_MESSAGES_LIMIT } from "@/lib/plans";

export const maxDuration = 60;

const schema = z.object({
  sessionId: z.string().max(64).nullish(),
  message: z.string().trim().min(2, "اكتب سؤالاً أطول قليلاً").max(2000, "السؤال طويل جداً"),
});

const SYSTEM_PROMPT = `أنت "Islamic GPT"، مساعد إسلامي ذكي وأمين. تتبع القواعد التالية بدقة إلزامية:

١) المصدر والاقتباس:
- اعتمد في إجابتك على الآيات المعطاة لك في قسم "نتائج البحث في القرآن" وعلى المعلومات الشرعية الراسخة المعروفة.
- كل آية تقتبسها يجب أن تذكر بعدها اسم السورة ورقم الآية بين قوسين، مثال: ﴿إِنَّ اللَّهَ مَعَ الصَّابِرِينَ﴾ (البقرة: ١٥٣).
- ممنوع منعاً باتاً اختراع آيات أو أحاديث أو نسبة كلام لأحد من دون مصدر. إذا لم تكن متأكداً من نص حديث أو مصدره، قل ذلك صراحة واكتفِ بما تعرفه يقيناً.

٢) الأسئلة الفقهية:
- اشرح الحكم باختصار ووضوح مع دليله من القرآن أو السنة المشهورة.
- عند اقتباس آية من "نتائج البحث في القرآن"، انقل نصها ومرجعها (اسم السورة ورقم الآية) كما ورد في نتائج البحث دون تغيير.
- إذا كان هناك خلاف مشهور بين العلماء في المسألة، صرّح بذلك بعبارة واضحة مثل: "في هذه المسألة خلاف بين العلماء: جمهور العلماء قالوا كذا، وذهب بعض العلماء إلى كذا".
- اختم الإجابات الفقهية دائماً بتنبيه لطيف من سطر واحد: الفتوى الشخصية والتفصيلية تُؤخذ من عالم موثوق.

٣) الأسلوب:
- عربي فصيح مبسّط، دافئ ومحترم.
- استخدم تنسيق Markdown بسيطاً: عناوين صغيرة (###) عند تعدد الأقسام، وقوائم مرقمة أو نقطية للخطوات، وخط عريض للكلمات المفتاحية.
- كل آية تقتبسها ضعها بين الرمزين ﴿ ﴾ مع ذكر المصدر بعدها مباشرة.
- لا تطول الإجابة أكثر من اللازم؛ اجعلها في حدود ما يخدم السؤال.
- إذا كان السؤال خارج النطاق الديني تماماً، أجب بإيجاز مهذب ثم عُد لنطاقك.
- لا تتظاهر بأنك مفتٍ رسمي؛ أنت أداة مساعدة للفهم والمعرفة.`;

function formatHits(hits: SearchHit[]): string {
  if (hits.length === 0) return "لا توجد نتائج بحث مباشرة.";
  return hits
    .map((h) => `- ﴿${h.text}﴾ (${h.surahName}: ${h.ayah})`)
    .join("\n");
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) {
    return NextResponse.json(
      { error: "سجّل الدخول أولاً لاستخدام المحادثة" },
      { status: 401 }
    );
  }

  // حماية من الإرسال المتكرر: ١٢ رسالة كل دقيقة
  const rl = rateLimit(`chat:${user.id}`, 12, 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `رسائل كثيرة جداً، انتظر ${rl.retryAfterSec} ثانية` },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "بيانات غير صالحة" },
      { status: 400 }
    );
  }
  const { message } = parsed.data;
  let sessionId = parsed.data.sessionId;

  // ---------- التحقق من الرصيد ----------
  const dbUser = await db.user.findUnique({ where: { id: user.id } });
  if (!dbUser) {
    return NextResponse.json({ error: "حساب غير موجود" }, { status: 401 });
  }
  if (dbUser.plan === "FREE" && dbUser.freeMessagesUsed >= FREE_MESSAGES_LIMIT) {
    return NextResponse.json(
      {
        error: "انتهت رسائلك المجانية (٥٠ رسالة)",
        code: "BALANCE_EXHAUSTED",
        invite: "اشترك الآن في باقة مدفوعة لتحصل على رصيد كلمات كبير ونتابع الحديث معاً 🌿",
      },
      { status: 402 }
    );
  }
  if (dbUser.plan !== "FREE" && dbUser.wordBalance <= 0) {
    return NextResponse.json(
      {
        error: "انتهى رصيد كلماتك",
        code: "BALANCE_EXHAUSTED",
        invite: "يمكنك تجديد اشتراكك من صفحة الباقات لنتواصل مرة أخرى 🌿",
      },
      { status: 402 }
    );
  }

  // ---------- الجلسة ----------
  let session;
  if (sessionId) {
    session = await db.chatSession.findFirst({
      where: { id: sessionId, userId: user.id },
      include: { messages: { orderBy: { createdAt: "asc" }, take: 200 } },
    });
  }
  if (!session) {
    session = await db.chatSession.create({
      data: {
        userId: user.id,
        title: message.slice(0, 40),
        messages: {},
      },
      include: { messages: true },
    });
    sessionId = session.id;
  }

  // ---------- بحث حقيقي في القرآن ----------
  let hits: SearchHit[] = [];
  try {
    hits = await searchQuran(message, 6);
  } catch {
    hits = [];
  }

  // ---------- سياق المحادثة السابقة ----------
  const history = session.messages.slice(-10).map((m) => ({
    role: m.role === "USER" ? ("user" as const) : ("assistant" as const),
    content: m.content,
  }));

  const contextBlock = `نتائج البحث في القرآن (استخدمها إن كانت ذات صلة واذكر المصدر):
${formatHits(hits)}`;

  // ---------- استدعاء النموذج (backend فقط) مع إعادة محاولة تلقائية للأخطاء المؤقتة ----------
  let reply = "";
  let lastAiError: unknown = null;
  for (let attempt = 1; attempt <= 2 && !reply; attempt++) {
    try {
      const completion = await zai.chat.completions.create({
        messages: [
          { role: "system", content: SYSTEM_PROMPT },
          { role: "system", content: contextBlock },
          ...history,
          { role: "user", content: message },
        ],
        thinking: { type: "disabled" },
      });
      reply = completion.choices[0]?.message?.content?.trim() ?? "";
      if (!reply && attempt === 1) {
        // رد فارغ: محاولة ثانية بعد مهلة قصيرة
        await new Promise((r) => setTimeout(r, 1200));
      }
    } catch (e) {
      lastAiError = e;
      if (attempt === 1) {
        await new Promise((r) => setTimeout(r, 1500));
      }
    }
  }
  if (!reply) {
    console.error("AI error:", lastAiError);
    return NextResponse.json(
      { error: "تعذّر الاتصال بخدمة الذكاء الاصطناعي، حاول مرة أخرى" },
      { status: 502 }
    );
  }

  // ---------- احتساب الرصيد وتحديثه ----------
  const wordCount = reply.split(/\s+/).filter(Boolean).length;
  let updatedUser = dbUser;
  if (dbUser.plan === "FREE") {
    updatedUser = await db.user.update({
      where: { id: dbUser.id },
      data: { freeMessagesUsed: { increment: 1 } },
    });
  } else {
    updatedUser = await db.user.update({
      where: { id: dbUser.id },
      data: { wordBalance: { decrement: wordCount } },
    });
  }

  // ---------- حفظ الرسائل ----------
  await db.chatMessage.createMany({
    data: [
      { sessionId: session.id, role: "USER", content: message },
      { sessionId: session.id, role: "ASSISTANT", content: reply },
    ],
  });
  await db.chatSession.update({
    where: { id: session.id },
    data: { updatedAt: new Date() },
  });

  const {
    id: _id,
    passwordHash: _ph,
    email: _e,
    name: _n,
    role: _r,
    createdAt: _c,
    updatedAt: _u,
    ...safeBalance
  } = updatedUser;

  return NextResponse.json({
    reply,
    sessionId: session.id,
    hits,
    wordCount,
    wordBalance: updatedUser.wordBalance,
    freeMessagesUsed: updatedUser.freeMessagesUsed,
  });
}
