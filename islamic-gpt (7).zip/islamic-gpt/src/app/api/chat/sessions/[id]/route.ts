import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";

// رسائل محادثة معينة
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await params;

  const session = await db.chatSession.findFirst({
    where: { id, userId: user.id },
    include: {
      messages: {
        select: { id: true, role: true, content: true, createdAt: true },
        orderBy: { createdAt: "asc" },
      },
    },
  });
  if (!session) return NextResponse.json({ error: "غير موجودة" }, { status: 404 });

  return NextResponse.json({
    session: { id: session.id, title: session.title },
    messages: session.messages,
  });
}

// حذف محادثة
export async function DELETE(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });
  const { id } = await params;

  const session = await db.chatSession.findFirst({ where: { id, userId: user.id } });
  if (!session) return NextResponse.json({ error: "غير موجودة" }, { status: 404 });

  await db.chatSession.delete({ where: { id } });
  return NextResponse.json({ ok: true });
}
