import { NextResponse } from "next/server";
import { db } from "@/lib/db";

// آية اليوم: اختيار ثابت لكل يوم بتقويم ميلادي
export async function GET() {
  const today = new Date();
  const dayOfYear = Math.floor(
    (today.getTime() - new Date(today.getFullYear(), 0, 0).getTime()) / 86400000
  );
  // ٦٢٣٦ آية — اخترنا آيات من سور مشهورة لتجربة أجمل
  const featuredSurahs = [
    2, 3, 13, 14, 17, 18, 20, 24, 25, 29, 31, 33, 39, 41, 42, 49, 50, 55, 57,
    59, 62, 65, 67, 73, 76, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99,
    100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112, 113, 114,
  ];
  const surahNumber = featuredSurahs[dayOfYear % featuredSurahs.length];
  const surah = await db.surah.findUnique({ where: { number: surahNumber } });
  if (!surah) return NextResponse.json({ verse: null });

  const ayahNumber = (dayOfYear % surah.numberOfAyahs) + 1;
  const ayah = await db.ayah.findUnique({
    where: { surahNumber_numberInSurah: { surahNumber, numberInSurah: ayahNumber } },
  });
  if (!ayah) return NextResponse.json({ verse: null });

  return NextResponse.json({
    verse: {
      text: ayah.text,
      surah: surah.number,
      surahName: surah.name,
      ayah: ayah.numberInSurah,
    },
  });
}
