import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";

const schema = z.object({
  surah: z.number().int().min(1).max(114),
  ayah: z.number().int().min(1).max(286),
  audioTime: z.number().min(0).max(60 * 60 * 3).optional(),
});

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ progress: null });
  const progress = await db.quranProgress.findUnique({
    where: { userId: user.id },
  });
  return NextResponse.json({ progress });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ ok: false }, { status: 401 });

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ ok: false }, { status: 400 });
  }
  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json({ ok: false }, { status: 400 });
  }

  await db.quranProgress.upsert({
    where: { userId: user.id },
    update: {
      surah: parsed.data.surah,
      ayah: parsed.data.ayah,
      audioTime: parsed.data.audioTime ?? 0,
    },
    create: {
      userId: user.id,
      surah: parsed.data.surah,
      ayah: parsed.data.ayah,
      audioTime: parsed.data.audioTime ?? 0,
    },
  });
  return NextResponse.json({ ok: true });
}
