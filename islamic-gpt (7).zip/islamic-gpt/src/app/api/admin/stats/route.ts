import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";

export async function GET() {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 403 });

  const [users, pending, approved, rejected, subs, revenueAgg] = await Promise.all([
    db.user.count(),
    db.subscriptionRequest.count({ where: { status: "PENDING" } }),
    db.subscriptionRequest.count({ where: { status: "APPROVED" } }),
    db.subscriptionRequest.count({ where: { status: "REJECTED" } }),
    db.subscription.count({ where: { active: true } }),
    db.subscriptionRequest.aggregate({
      where: { status: "APPROVED" },
      _sum: { amount: true },
    }),
  ]);

  return NextResponse.json({
    stats: {
      users,
      pendingRequests: pending,
      approvedRequests: approved,
      rejectedRequests: rejected,
      activeSubscriptions: subs,
      totalRevenueEgp: revenueAgg._sum.amount ?? 0,
    },
  });
}
