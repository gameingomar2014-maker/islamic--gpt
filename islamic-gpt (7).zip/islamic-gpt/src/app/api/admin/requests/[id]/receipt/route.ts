import { NextResponse } from "next/server";
import { db } from "@/lib/db";
import { requireAdmin } from "@/lib/auth";

// صورة إيصال — للأدمن فقط
export async function GET(
  _req: Request,
  { params }: { params: Promise<{ id: string }> }
) {
  const admin = await requireAdmin();
  if (!admin) return NextResponse.json({ error: "غير مصرح" }, { status: 403 });
  const { id } = await params;

  const request = await db.subscriptionRequest.findUnique({
    where: { id },
    select: { receiptImage: true },
  });
  if (!request || !request.receiptImage) {
    return NextResponse.json({ error: "لا يوجد إيصال" }, { status: 404 });
  }
  return NextResponse.json({ receiptImage: request.receiptImage });
}
