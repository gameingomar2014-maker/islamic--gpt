import { NextResponse } from "next/server";
import { z } from "zod";
import { db } from "@/lib/db";
import { getCurrentUser } from "@/lib/auth";
import { rateLimit } from "@/lib/rate-limit";
import { getPlan, PAYMENT_METHODS } from "@/lib/plans";

const MAX_RECEIPT_CHARS = 3_600_000; // ≈ 2.6 ميجابايت بعد الترميز

const schema = z.object({
  planId: z.enum(["WORDS_500", "WORDS_1500"]),
  userName: z.string().trim().min(2, "الاسم قصير جداً").max(80),
  phone: z
    .string()
    .trim()
    .regex(/^[0-9+\s-]{8,15}$/, "رقم موبايل غير صالح"),
  paymentMethod: z.enum([
    "vodafone_cash",
    "etisalat_cash",
    "orange_cash",
    "instapay",
    "bank",
  ]),
  transactionRef: z.string().trim().max(60).nullish().or(z.literal("")),
  receiptImage: z
    .string()
    .regex(
      /^data:image\/(jpeg|jpg|png|webp);base64,[A-Za-z0-9+/=]+$/,
      "صورة غير صالحة (المسموح: JPG أو PNG أو WEBP)"
    )
    .max(MAX_RECEIPT_CHARS, "حجم الصورة كبير جداً (الحد ٢ ميجابايت)")
    .optional()
    .or(z.literal("")),
});

// طلباتي
export async function GET() {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

  const requests = await db.subscriptionRequest.findMany({
    where: { userId: user.id },
    select: {
      id: true,
      planId: true,
      amount: true,
      words: true,
      paymentMethod: true,
      transactionRef: true,
      status: true,
      adminNote: true,
      createdAt: true,
      reviewedAt: true,
    },
    orderBy: { createdAt: "desc" },
  });

  // معرفة أي الطلبات تحتوي إيصالاً (بدون تحميل الصور نفسها)
  const withReceipt = await db.subscriptionRequest.findMany({
    where: { userId: user.id, receiptImage: { not: null } },
    select: { id: true },
  });
  const receiptIds = new Set(withReceipt.map((r) => r.id));

  return NextResponse.json({
    requests: requests.map((r) => ({ ...r, hasReceipt: receiptIds.has(r.id) })),
  });
}

// إنشاء طلب اشتراك جديد
export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "غير مصرح" }, { status: 401 });

  const rl = rateLimit(`request:${user.id}`, 5, 60 * 60 * 1000);
  if (!rl.allowed) {
    return NextResponse.json(
      { error: `طلبات كثيرة، حاول بعد ${rl.retryAfterSec} ثانية` },
      { status: 429 }
    );
  }

  let body: unknown;
  try {
    body = await req.json();
  } catch {
    return NextResponse.json({ error: "بيانات غير صالحة" }, { status: 400 });
  }

  const parsed = schema.safeParse(body);
  if (!parsed.success) {
    return NextResponse.json(
      { error: parsed.error.issues[0]?.message ?? "بيانات غير صالحة" },
      { status: 400 }
    );
  }

  const data = parsed.data;
  const plan = getPlan(data.planId);
  if (!plan) {
    return NextResponse.json({ error: "باقة غير موجودة" }, { status: 400 });
  }
  if (!data.transactionRef && !data.receiptImage) {
    return NextResponse.json(
      { error: "أدخل رقم العملية أو أرفق صورة الإيصال" },
      { status: 400 }
    );
  }
  if (!PAYMENT_METHODS.some((m) => m.id === data.paymentMethod)) {
    return NextResponse.json({ error: "طريقة دفع غير معروفة" }, { status: 400 });
  }

  // منع تكرار الطلبات المعلقة لنفس الباقة
  const pendingSame = await db.subscriptionRequest.findFirst({
    where: { userId: user.id, planId: data.planId, status: "PENDING" },
  });
  if (pendingSame) {
    return NextResponse.json(
      { error: "لديك طلب معلّق لنفس الباقة بالفعل، انتظر مراجعة الإدارة" },
      { status: 409 }
    );
  }

  const request = await db.subscriptionRequest.create({
    data: {
      userId: user.id,
      planId: plan.id,
      userName: data.userName,
      phone: data.phone,
      paymentMethod: data.paymentMethod,
      transactionRef: data.transactionRef || null,
      receiptImage: data.receiptImage || null,
      status: "PENDING",
      amount: plan.priceEgp,
      words: plan.words,
    },
  });

  return NextResponse.json(
    {
      ok: true,
      request: { id: request.id, status: request.status },
      message: "تم إرسال طلبك للإدارة بنجاح، وسنخبرك بالنتيجة قريباً بإذن الله",
    },
    { status: 201 }
  );
}
