"use client";

import { useEffect, useState } from "react";
import {
  useStore,
  navigate,
  Route,
} from "@/lib/store";
import { balanceText, FREE_MESSAGES_LIMIT } from "@/lib/plans";
import { PlayerBar } from "@/components/quran/PlayerBar";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  Home,
  BookOpen,
  MessageCircle,
  CreditCard,
  User,
  ShieldCheck,
  LogOut,
  Wallet,
} from "lucide-react";

export function MosqueLogo({ className = "w-8 h-8" }: { className?: string }) {
  return (
    <svg viewBox="0 0 64 64" fill="none" className={className} aria-hidden="true">
      <path
        d="M32 8c-1 4-7 7-7 13 0 4.4 3.1 7.5 7 7.5s7-3.1 7-7.5c0-6-6-9-7-13z"
        fill="#ecc468"
      />
      <rect x="12" y="34" width="40" height="20" rx="2" fill="#064e3b" />
      <rect x="6" y="24" width="5" height="30" rx="1.5" fill="#065f46" />
      <rect x="53" y="24" width="5" height="30" rx="1.5" fill="#065f46" />
      <circle cx="8.5" cy="21" r="3" fill="#10b981" />
      <circle cx="55.5" cy="21" r="3" fill="#10b981" />
      <path d="M27 54v-8a5 5 0 0 1 10 0v8z" fill="#ecc468" />
    </svg>
  );
}

export const NAV_ITEMS: { route: Route; label: string; icon: React.ElementType; path: string }[] = [
  { route: { view: "home" } as Route, label: "الرئيسية", icon: Home, path: "/" },
  { route: { view: "quran" } as Route, label: "القرآن", icon: BookOpen, path: "/quran" },
  { route: { view: "chat" } as Route, label: "المحادثة", icon: MessageCircle, path: "/chat" },
  { route: { view: "plans" } as Route, label: "الاشتراك", icon: CreditCard, path: "/plans" },
];

export function isActive(current: Route, target: Route): boolean {
  return current.view === target.view;
}

export function BalanceChip({ compact = false }: { compact?: boolean }) {
  const user = useStore((s) => s.user);
  if (!user) return null;
  const isFree = user.plan === "FREE";
  const remaining = Math.max(0, FREE_MESSAGES_LIMIT - user.freeMessagesUsed);
  const low = isFree ? remaining <= 5 : user.wordBalance <= 50;
  return (
    <button
      onClick={() => navigate("/plans")}
      title="اضغط للاشتراك في باقة أكبر"
      className={`flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full border transition-colors ${
        low
          ? "bg-amber-50 border-amber-300 text-amber-700 hover:bg-amber-100"
          : "bg-islamic-50 border-emerald-200 text-islamic-700 hover:bg-emerald-100"
      }`}
    >
      <Wallet className="w-3.5 h-3.5" />
      {balanceText(user)}
      {!compact && <span className="text-gold">↑</span>}
    </button>
  );
}

export function AppShell({ children }: { children: React.ReactNode }) {
  const route = useStore((s) => s.route);
  const user = useStore((s) => s.user);
  const logout = useStore((s) => s.logout);
  const player = useStore((s) => s.player);
  const [scrolled, setScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 8);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const hasPlayer = !!player.url;

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* ---------- الهيدر (كمبيوتر) ---------- */}
      <header
        className={`sticky top-0 z-40 hidden md:block border-b border-border/60 backdrop-blur-md bg-background/85 transition-shadow ${
          scrolled ? "shadow-sm" : ""
        }`}
      >
        <div className="max-w-6xl mx-auto px-4 h-16 flex items-center gap-6">
          <button
            onClick={() => navigate("/")}
            className="flex items-center gap-2 shrink-0"
            aria-label="Islamic GPT - الرئيسية"
          >
            <MosqueLogo className="w-9 h-9" />
            <span className="text-xl font-extrabold text-islamic-800">
              Islamic <span className="text-gold">GPT</span>
            </span>
          </button>

          <nav className="flex items-center gap-1" aria-label="التنقل الرئيسي">
            {NAV_ITEMS.map((item) => (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
                  isActive(route, item.route)
                    ? "bg-islamic-800 text-primary-foreground"
                    : "text-foreground/80 hover:bg-secondary"
                }`}
              >
                {item.label}
              </button>
            ))}
            <button
              onClick={() => navigate("/about")}
              className={`px-4 py-2 rounded-full text-sm font-semibold transition-colors ${
                isActive(route, { view: "about" })
                  ? "bg-islamic-800 text-primary-foreground"
                  : "text-foreground/80 hover:bg-secondary"
              }`}
            >
              عن الموقع
            </button>
          </nav>

          <div className="mr-auto flex items-center gap-3">
            {user && <BalanceChip />}
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="outline" className="gap-2 rounded-full">
                    <User className="w-4 h-4" />
                    <span className="max-w-28 truncate">{user.name}</span>
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="start" className="w-56">
                  <DropdownMenuLabel className="text-xs text-muted-foreground">
                    {user.email}
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => navigate("/account")} className="gap-2">
                    <Wallet className="w-4 h-4" /> حسابي واشتراكي
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => navigate("/plans")} className="gap-2">
                    <CreditCard className="w-4 h-4" /> الباقات
                  </DropdownMenuItem>
                  {user.role === "ADMIN" && (
                    <DropdownMenuItem onClick={() => navigate("/admin")} className="gap-2">
                      <ShieldCheck className="w-4 h-4" /> لوحة الإدارة
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout} className="gap-2 text-destructive">
                    <LogOut className="w-4 h-4" /> تسجيل الخروج
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button
                onClick={() => navigate("/login")}
                className="rounded-full bg-islamic-800 hover:bg-islamic-700"
              >
                تسجيل الدخول
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* ---------- شريط علوي مصغّر للموبايل ---------- */}
      <header className="sticky top-0 z-40 md:hidden border-b border-border/60 backdrop-blur-md bg-background/85">
        <div className="px-4 h-14 flex items-center justify-between">
          <button onClick={() => navigate("/")} className="flex items-center gap-2">
            <MosqueLogo className="w-8 h-8" />
            <span className="text-lg font-extrabold text-islamic-800">
              Islamic <span className="text-gold">GPT</span>
            </span>
          </button>
          <div className="flex items-center gap-2">
            {user ? (
              <button
                onClick={() => navigate("/account")}
                className="flex items-center gap-1.5 text-xs font-bold px-3 py-1.5 rounded-full bg-secondary text-islamic-800"
                aria-label="حسابي"
              >
                <User className="w-3.5 h-3.5" />
                {user.name.split(" ")[0]}
              </button>
            ) : (
              <Button
                onClick={() => navigate("/login")}
                size="sm"
                className="rounded-full bg-islamic-800 hover:bg-islamic-700 h-8 text-xs"
              >
                دخول
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* ---------- المحتوى ---------- */}
      <main className="flex-1 animate-fade-up pb-44 md:pb-36">{children}</main>

      {/* ---------- الفوتر ---------- */}
      <footer className="mt-auto border-t border-border/60 bg-islamic-900 text-emerald-50/90">
        <div className="max-w-6xl mx-auto px-4 py-8 grid gap-6 md:grid-cols-3 text-sm">
          <div>
            <div className="flex items-center gap-2 mb-3">
              <MosqueLogo className="w-7 h-7" />
              <span className="font-extrabold text-base">
                Islamic <span className="text-gold-soft">GPT</span>
              </span>
            </div>
            <p className="leading-7 text-emerald-100/70">
              منصة إسلامية تجمع بين القرآن الكريم بالتلاوة ومحادثة ذكية تعتمد على
              كتاب الله، بنية صادقة ووضوح في المصادر.
            </p>
          </div>
          <div>
            <h3 className="font-bold mb-3 text-gold-soft">روابط سريعة</h3>
            <ul className="space-y-2">
              <li>
                <button onClick={() => navigate("/quran")} className="hover:text-white transition-colors">
                  القرآن الكريم
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/chat")} className="hover:text-white transition-colors">
                  المحادثة الإسلامية
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/plans")} className="hover:text-white transition-colors">
                  الباقات والاشتراك
                </button>
              </li>
              <li>
                <button onClick={() => navigate("/about")} className="hover:text-white transition-colors">
                  عن الموقع والمصادر
                </button>
              </li>
            </ul>
          </div>
          <div>
            <h3 className="font-bold mb-3 text-gold-soft">تنبيه مهم</h3>
            <p className="leading-7 text-emerald-100/70">
              المحادثة الذكية وسيلة للفهم والمعرفة، وليست بديلاً عن فتوى عالم
              موثوق. الفتوى الشخصية تُؤخذ من أهل العلم.
            </p>
          </div>
        </div>
        <div className="border-t border-white/10 py-4 text-center text-xs text-emerald-100/60">
          نص القرآن: مشروع AlQuran Cloud — التلاوات: موقع mp3quran.net
        </div>
      </footer>

      {/* ---------- مشغل التلاوة الثابت ---------- */}
      {hasPlayer && <PlayerBar />}

      {/* ---------- شريط التنقل السفلي (موبايل) ---------- */}
      <nav
        className={`fixed bottom-0 inset-x-0 z-40 md:hidden border-t border-border/70 bg-white/95 backdrop-blur-md pb-safe ${
          hasPlayer ? "hidden" : ""
        }`}
        aria-label="التنقل السفلي"
      >
        <div className="grid grid-cols-4 h-16">
          {NAV_ITEMS.map((item) => {
            const Icon = item.icon;
            const active = isActive(route, item.route);
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                className={`relative flex flex-col items-center justify-center gap-1 text-[11px] font-bold transition-colors ${
                  active ? "text-islamic-600" : "text-muted-foreground"
                }`}
              >
                <Icon className={`w-5 h-5 ${active ? "scale-110" : ""} transition-transform`} />
                {item.label}
                <span
                  className={`absolute top-0 h-0.5 w-10 rounded-full ${
                    active ? "bg-islamic-500" : "bg-transparent"
                  }`}
                />
              </button>
            );
          })}
        </div>
      </nav>
    </div>
  );
}
