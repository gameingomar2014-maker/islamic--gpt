"use client";

import { useEffect, useRef } from "react";
import { useStore, getAudioElement, RECITERS } from "@/lib/store";
import { Slider } from "@/components/ui/slider";
import { Button } from "@/components/ui/button";
import {
  Play,
  Pause,
  SkipBack,
  SkipForward,
  Gauge,
  X,
  Download,
  Loader2,
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

const SPEEDS = [0.75, 1, 1.25, 1.5, 2];

function fmtTime(t: number): string {
  if (!isFinite(t) || t < 0) t = 0;
  const m = Math.floor(t / 60);
  const s = Math.floor(t % 60);
  return `${m}:${String(s).padStart(2, "0")}`;
}

export function PlayerBar() {
  const player = useStore((s) => s.player);
  const togglePlay = useStore((s) => s.togglePlay);
  const seek = useStore((s) => s.seek);
  const setSpeed = useStore((s) => s.setSpeed);
  const playAdjacent = useStore((s) => s.playAdjacent);
  const updateFromAudio = useStore((s) => s.updateFromAudio);
  const persistPosition = useStore((s) => s.persistPosition);
  const lastPersist = useRef(0);

  // ربط أحداث الصوت مرة واحدة
  useEffect(() => {
    const audio = getAudioElement();
    if (!audio) return;

    const onTime = () => {
      updateFromAudio({ currentTime: audio.currentTime });
      const now = Date.now();
      if (now - lastPersist.current > 5000 && !audio.paused) {
        lastPersist.current = now;
        useStore.getState().persistPosition();
      }
    };
    const onMeta = () => updateFromAudio({ duration: audio.duration || 0 });
    const onPlay = () => updateFromAudio({ playing: true });
    const onPause = () => {
      updateFromAudio({ playing: false });
      useStore.getState().persistPosition();
    };
    const onEnded = () => {
      useStore.getState().persistPosition();
      playAdjacent(1);
    };

    audio.addEventListener("timeupdate", onTime);
    audio.addEventListener("loadedmetadata", onMeta);
    audio.addEventListener("durationchange", onMeta);
    audio.addEventListener("play", onPlay);
    audio.addEventListener("pause", onPause);
    audio.addEventListener("ended", onEnded);
    return () => {
      audio.removeEventListener("timeupdate", onTime);
      audio.removeEventListener("loadedmetadata", onMeta);
      audio.removeEventListener("durationchange", onMeta);
      audio.removeEventListener("play", onPlay);
      audio.removeEventListener("pause", onPause);
      audio.removeEventListener("ended", onEnded);
    };
  }, [updateFromAudio, playAdjacent]);

  const reciter = RECITERS.find((r) => r.id === player.reciterId);
  const progress = player.duration > 0 ? (player.currentTime / player.duration) * 100 : 0;

  return (
    <div className="fixed bottom-0 inset-x-0 z-50 md:z-40">
      <div className="bg-white/95 backdrop-blur-md border-t border-border shadow-[0_-4px_20px_rgba(6,78,59,0.08)]">
        {/* شريط التقدم العلوي الرفيع */}
        <div className="h-1 w-full bg-muted">
          <div
            className="h-full bg-gradient-to-l from-islamic-500 to-gold-soft transition-[width] duration-200"
            style={{ width: `${progress}%` }}
          />
        </div>

        <div className="max-w-6xl mx-auto px-3 md:px-4 py-2.5 flex items-center gap-3">
          {/* أزرار التحكم */}
          <div className="flex items-center gap-1 shrink-0">
            <Button
              size="icon"
              variant="ghost"
              onClick={() => playAdjacent(-1)}
              className="rounded-full w-9 h-9"
              aria-label="السورة السابقة"
            >
              <SkipBack className="w-4 h-4" />
            </Button>
            <Button
              size="icon"
              onClick={togglePlay}
              className="rounded-full w-11 h-11 bg-islamic-800 hover:bg-islamic-700 shadow-md"
              aria-label={player.playing ? "إيقاف" : "تشغيل"}
            >
              {player.loading ? (
                <Loader2 className="w-5 h-5 animate-spin" />
              ) : player.playing ? (
                <Pause className="w-5 h-5" />
              ) : (
                <Play className="w-5 h-5 -mr-0.5" />
              )}
            </Button>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => playAdjacent(1)}
              className="rounded-full w-9 h-9"
              aria-label="السورة التالية"
            >
              <SkipForward className="w-4 h-4" />
            </Button>
          </div>

          {/* العنوان */}
          <div className="min-w-0 shrink">
            <p className="text-sm font-extrabold text-islamic-800 truncate">
              سورة {player.surahName || String(player.surah)}
            </p>
            <p className="text-[11px] text-muted-foreground truncate">
              {reciter?.name ?? ""}
            </p>
          </div>

          {/* شريط التقدم (كمبيوتر) */}
          <div className="hidden md:flex items-center gap-3 flex-1">
            <span className="text-[11px] tabular-nums text-muted-foreground w-10 text-center">
              {fmtTime(player.currentTime)}
            </span>
            <Slider
              value={[player.currentTime]}
              max={player.duration || 1}
              step={1}
              onValueChange={([v]) => seek(v)}
              className="flex-1"
              aria-label="شريط تقدم التلاوة"
            />
            <span className="text-[11px] tabular-nums text-muted-foreground w-10 text-center">
              {fmtTime(player.duration)}
            </span>
          </div>

          {/* شريط التقدم (موبايل) */}
          <div className="md:hidden flex-1 px-1 min-w-0">
            <Slider
              value={[player.currentTime]}
              max={player.duration || 1}
              step={1}
              onValueChange={([v]) => seek(v)}
              aria-label="شريط تقدم التلاوة"
            />
            <div className="flex justify-between gap-3 text-[10px] tabular-nums text-muted-foreground mt-0.5">
              <span className="whitespace-nowrap">{fmtTime(player.currentTime)}</span>
              <span className="whitespace-nowrap">{fmtTime(player.duration)}</span>
            </div>
          </div>

          {/* السرعة والتحميل */}
          <div className="flex items-center gap-1 shrink-0">
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button
                  size="sm"
                  variant="outline"
                  className="rounded-full gap-1 text-xs h-9"
                  aria-label="سرعة التلاوة"
                >
                  <Gauge className="w-3.5 h-3.5" />
                  {player.speed}x
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start">
                {SPEEDS.map((s) => (
                  <DropdownMenuItem
                    key={s}
                    onClick={() => setSpeed(s)}
                    className={s === player.speed ? "bg-secondary font-bold" : ""}
                  >
                    {s}x {s === 1 ? "(عادية)" : ""}
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>

            <Button
              size="icon"
              variant="ghost"
              className="rounded-full w-9 h-9 hidden md:inline-flex"
              asChild
              aria-label="تحميل السورة"
            >
              <a href={player.url} download={`surah-${player.surah}.mp3`} target="_blank" rel="noreferrer">
                <Download className="w-4 h-4" />
              </a>
            </Button>

            <Button
              size="icon"
              variant="ghost"
              className="rounded-full w-9 h-9 text-muted-foreground"
              onClick={() => {
                persistPosition();
                const audio = getAudioElement();
                if (audio) {
                  audio.pause();
                  audio.removeAttribute("src");
                }
                useStore.setState((s) => ({
                  player: { ...s.player, url: "", playing: false, currentTime: 0, duration: 0 },
                }));
              }}
              aria-label="إغلاق المشغل"
            >
              <X className="w-4 h-4" />
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}
