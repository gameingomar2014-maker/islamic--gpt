"use client";

import { useEffect, useMemo, useRef, useState } from "react";
import { useStore, navigate, RECITERS } from "@/lib/store";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Play,
  Pause,
  ChevronRight,
  ChevronLeft,
  Download,
  History,
  ListFilter,
} from "lucide-react";

const BISMILLAH = "بِسْمِ ٱللَّهِ ٱلرَّحْمَٰنِ ٱلرَّحِيمِ";

function toArabicDigits(n: number): string {
  return String(n).replace(/[0-9]/g, (d) => "٠١٢٣٤٥٦٧٨٩"[parseInt(d)]);
}

type SurahData = {
  number: number;
  name: string;
  englishName: string;
  revelationType: string;
  numberOfAyahs: number;
  showBismillah: boolean;
  ayahs: { numberInSurah: number; text: string }[];
};

export function SurahView({ surahNumber }: { surahNumber: number }) {
  const [data, setData] = useState<SurahData | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [fontSize, setFontSize] = useState(28);
  const player = useStore((s) => s.player);
  const playSurah = useStore((s) => s.playSurah);
  const setReciter = useStore((s) => s.setReciter);
  const [savedPos, setSavedPos] = useState<number | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  // التحميل مشتق من البيانات: نعرض سكلتن حتى تصل بيانات السورة المطلوبة
  const loading = !data || data.number !== surahNumber;

  useEffect(() => {
    let cancelled = false;
    fetch(`/api/quran/surah/${surahNumber}`)
      .then((r) => {
        if (!r.ok) throw new Error("خطأ في تحميل السورة");
        return r.json();
      })
      .then((d) => {
        if (cancelled) return;
        setData(d.surah);
        setError(null);
        // آخر موضع محفوظ محلياً لهذه السورة
        try {
          const pos = parseFloat(localStorage.getItem(`ig_pos_${surahNumber}`) || "");
          setSavedPos(!isNaN(pos) && pos > 10 ? pos : null);
        } catch {
          setSavedPos(null);
        }
      })
      .catch(() => {
        if (cancelled) return;
        setError("تعذّر تحميل السورة، حاول تحديث الصفحة");
      });
    window.scrollTo({ top: 0 });
    return () => {
      cancelled = true;
    };
  }, [surahNumber]);

  const reciter = RECITERS.find((r) => r.id === player.reciterId) ?? RECITERS[0];
  const isCurrentSurah = player.url && player.surah === surahNumber;

  const audioUrl = useMemo(() => {
    if (!reciter) return "#";
    return `${reciter.server}/${String(surahNumber).padStart(3, "0")}.mp3`;
  }, [reciter, surahNumber]);

  const handlePlayClick = (resume?: number) => {
    if (isCurrentSurah) {
      useStore.getState().togglePlay();
      return;
    }
    playSurah(surahNumber, data?.name ?? "", {
      autoPlay: true,
      startTime: resume,
    });
    setSavedPos(null);
  };

  const fmt = (t: number) => {
    const m = Math.floor(t / 60);
    const s = Math.floor(t % 60);
    return `${m}:${String(s).padStart(2, "0")}`;
  };

  return (
    <div className="max-w-4xl mx-auto px-4 py-6 md:py-10">
      {/* تنقل بين السور */}
      <div className="flex items-center justify-between mb-5">
        <Button
          variant="outline"
          size="sm"
          className="rounded-full gap-1"
          onClick={() => surahNumber > 1 && navigate(`/surah/${surahNumber - 1}`)}
          disabled={surahNumber <= 1}
        >
          <ChevronRight className="w-4 h-4" />
          السابقة
        </Button>
        <Button
          variant="ghost"
          size="sm"
          className="rounded-full text-islamic-700"
          onClick={() => navigate("/quran")}
        >
          كل السور
        </Button>
        <Button
          variant="outline"
          size="sm"
          className="rounded-full gap-1"
          onClick={() => surahNumber < 114 && navigate(`/surah/${surahNumber + 1}`)}
          disabled={surahNumber >= 114}
        >
          التالية
          <ChevronLeft className="w-4 h-4" />
        </Button>
      </div>

      {/* رأس السورة */}
      <Card className="rounded-3xl border-islamic-200 bg-gradient-to-b from-islamic-50 to-white shadow-sm mb-6 overflow-hidden">
        <CardContent className="p-6 md:p-8 text-center relative">
          <div className="absolute inset-0 pattern-bg opacity-40" aria-hidden="true" />
          <div className="relative">
            <p className="text-xs font-bold text-gold mb-1">
              السورة رقم {toArabicDigits(surahNumber)}
            </p>
            <h1 className="font-quran text-4xl md:text-5xl font-bold text-islamic-900 mb-2">
              {data?.name ?? "…"}
            </h1>
            {data && (
              <p className="text-xs text-muted-foreground">
                {data.revelationType} • عدد آياتها {toArabicDigits(data.numberOfAyahs)}
              </p>
            )}

            {/* أزرار الاستماع */}
            <div className="mt-5 flex flex-wrap items-center justify-center gap-2">
              <Button
                onClick={() => handlePlayClick(savedPos ?? undefined)}
                className={`rounded-full gap-2 shadow-md ${
                  isCurrentSurah && player.playing
                    ? "bg-gold-soft text-islamic-900 hover:bg-gold-soft/90"
                    : "bg-islamic-800 hover:bg-islamic-700"
                }`}
              >
                {isCurrentSurah && player.playing ? (
                  <Pause className="w-4 h-4" />
                ) : (
                  <Play className="w-4 h-4" />
                )}
                {isCurrentSurah
                  ? player.playing
                    ? "إيقاف التلاوة"
                    : "متابعة التلاوة"
                  : savedPos
                  ? `متابعة من ${fmt(savedPos)}`
                  : "استمع للسورة"}
              </Button>

              <Button asChild variant="outline" className="rounded-full gap-2">
                <a href={audioUrl} download={`surah-${surahNumber}.mp3`} target="_blank" rel="noreferrer">
                  <Download className="w-4 h-4" />
                  تحميل السورة
                </a>
              </Button>

              {/* اختيار القارئ */}
              <Select
                value={String(player.reciterId)}
                onValueChange={(v) => setReciter(parseInt(v, 10))}
              >
                <SelectTrigger className="rounded-full w-56 h-10 bg-white text-sm" aria-label="اختيار القارئ">
                  <SelectValue placeholder="اختر القارئ" />
                </SelectTrigger>
                <SelectContent className="max-h-72">
                  {RECITERS.map((r) => (
                    <SelectItem key={r.id} value={String(r.id)}>
                      {r.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              {/* حجم الخط */}
              <Select value={String(fontSize)} onValueChange={(v) => setFontSize(parseInt(v, 10))}>
                <SelectTrigger className="rounded-full w-32 h-10 bg-white text-sm" aria-label="حجم خط المصحف">
                  <ListFilter className="w-3.5 h-3.5" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="22">خط صغير</SelectItem>
                  <SelectItem value="28">خط متوسط</SelectItem>
                  <SelectItem value="34">خط كبير</SelectItem>
                  <SelectItem value="42">خط كبير جداً</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* تنبيه موضع محفوظ من السيرفر */}
            {savedPos && !isCurrentSurah && (
              <p className="mt-3 text-xs text-muted-foreground flex items-center justify-center gap-1">
                <History className="w-3.5 h-3.5" />
                توقفت في هذه السورة عند {fmt(savedPos)} — اضغط "متابعة" لتكمل بإذن الله
              </p>
            )}
          </div>
        </CardContent>
      </Card>

      {/* نص السورة */}
      <Card className="rounded-3xl border-border/70 shadow-sm">
        <CardContent className="p-5 md:p-10">
          {loading ? (
            <div className="space-y-4">
              <Skeleton className="h-6 w-2/3 mx-auto" />
              <Skeleton className="h-24 w-full" />
              <Skeleton className="h-24 w-full" />
            </div>
          ) : error ? (
            <div className="text-center py-10 text-muted-foreground">
              <p className="font-bold text-destructive mb-2">{error}</p>
              <Button variant="outline" onClick={() => window.location.reload()}>
                إعادة المحاولة
              </Button>
            </div>
          ) : data ? (
            <div ref={containerRef} dir="rtl">
              {/* البسملة */}
              {data.showBismillah && (
                <p className="font-quran text-center text-2xl md:text-3xl text-islamic-800 mb-8">
                  {BISMILLAH}
                  <span className="block text-[11px] not-italic text-muted-foreground mt-1 font-sans">
                    بسملة
                  </span>
                </p>
              )}

              {/* الآيات متصلة كسطر المصحف */}
              <p
                className="font-quran leading-[2.4] text-justify text-islamic-950 tracking-normal"
                style={{ fontSize: `${fontSize}px`, textAlignLast: "center" }}
              >
                {data.ayahs.map((a) => (
                  <span key={a.numberInSurah} id={`ayah-${a.numberInSurah}`}>
                    {a.text}
                    <span className="ayah-num" title={`الآية ${a.numberInSurah}`}>
                      {toArabicDigits(a.numberInSurah)}
                    </span>{" "}
                  </span>
                ))}
              </p>

              {/* خاتمة */}
              <div className="mt-10 pt-6 border-t border-border/60 text-center">
                <p className="text-xs text-muted-foreground mb-3">
                  صدق الله العظيم — تم بحمد الله
                </p>
                <div className="flex justify-center gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    className="rounded-full gap-1"
                    onClick={() => surahNumber < 114 && navigate(`/surah/${surahNumber + 1}`)}
                    disabled={surahNumber >= 114}
                  >
                    السورة التالية
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                </div>
              </div>
            </div>
          ) : null}
        </CardContent>
      </Card>
    </div>
  );
}
