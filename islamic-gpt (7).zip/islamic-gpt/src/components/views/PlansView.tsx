"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { PLANS, PAYMENT_METHODS, getPlan, FREE_MESSAGES_LIMIT } from "@/lib/plans";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useToast } from "@/hooks/use-toast";
import {
  Check,
  CreditCard,
  Upload,
  FileText,
  BadgeCheck,
  Clock3,
  XCircle,
  Image as ImageIcon,
  LogIn,
} from "lucide-react";

type MyRequest = {
  id: string;
  planId: string;
  amount: number;
  words: number;
  paymentMethod: string;
  transactionRef: string | null;
  status: "PENDING" | "APPROVED" | "REJECTED";
  adminNote: string | null;
  createdAt: string;
  hasReceipt: boolean;
};

const STATUS_META: Record<
  string,
  { label: string; icon: React.ElementType; className: string }
> = {
  PENDING: {
    label: "بانتظار المراجعة",
    icon: Clock3,
    className: "bg-amber-50 text-amber-700 border-amber-300",
  },
  APPROVED: {
    label: "مقبول ومفعّل",
    icon: BadgeCheck,
    className: "bg-emerald-50 text-emerald-700 border-emerald-300",
  },
  REJECTED: {
    label: "مرفوض",
    icon: XCircle,
    className: "bg-red-50 text-red-700 border-red-300",
  },
};

function fmtDate(iso: string): string {
  try {
    return new Date(iso).toLocaleDateString("ar-EG", {
      year: "numeric",
      month: "long",
      day: "numeric",
    });
  } catch {
    return iso;
  }
}

export function PlansView() {
  const user = useStore((s) => s.user);
  const { toast } = useToast();
  const [dialogPlan, setDialogPlan] = useState<(typeof PLANS)[number] | null>(null);
  const [myRequests, setMyRequests] = useState<MyRequest[]>([]);

  const loadRequests = useCallback(async () => {
    if (!user) return;
    try {
      const res = await fetch("/api/requests");
      if (res.ok) {
        const d = await res.json();
        setMyRequests(d.requests ?? []);
      }
    } catch {}
  }, [user]);

  useEffect(() => {
    let cancelled = false;
    if (!user) return;
    fetch("/api/requests")
      .then((r) => (r.ok ? r.json() : null))
      .then((d) => {
        if (!cancelled) setMyRequests(d?.requests ?? []);
      })
      .catch(() => {});
    return () => {
      cancelled = true;
    };
  }, [user]);

  const isFree = user?.plan === "FREE";
  const remaining = user
    ? isFree
      ? Math.max(0, FREE_MESSAGES_LIMIT - user.freeMessagesUsed)
      : user.wordBalance
    : 0;

  return (
    <div className="max-w-5xl mx-auto px-4 py-6 md:py-10">
      {/* رأس */}
      <div className="text-center mb-8">
        <h1 className="text-2xl md:text-3xl font-extrabold text-islamic-800 flex items-center justify-center gap-2">
          <CreditCard className="w-7 h-7 text-islamic-600" />
          الباقات والاشتراك
        </h1>
        <p className="text-muted-foreground mt-2 text-sm md:text-base">
          اختر ما يناسبك — الدفع يدوي بتحويل محفظة، والتفعيل بعد مراجعة الإدارة
        </p>
        {user && (
          <div className="mt-4 inline-flex items-center gap-2 bg-islamic-50 border border-emerald-200 rounded-full px-5 py-2 text-sm font-bold text-islamic-800">
            رصيدك الحالي: {isFree ? `${remaining} رسالة من ${FREE_MESSAGES_LIMIT}` : `${remaining} كلمة`}
          </div>
        )}
      </div>

      {/* الباقات */}
      <div className="grid md:grid-cols-3 gap-4 md:gap-6 mb-12">
        <Card className="rounded-3xl border-border/80 shadow-sm">
          <CardContent className="p-6">
            <h3 className="font-extrabold text-lg text-islamic-800 mb-1">المجانية</h3>
            <p className="text-3xl font-extrabold text-islamic-900 mb-4">
              ٠ <span className="text-sm font-semibold text-muted-foreground">جنيه</span>
            </p>
            <ul className="space-y-2.5 text-sm text-foreground/80 mb-6">
              <li className="flex gap-2 items-start">
                <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                {FREE_MESSAGES_LIMIT} رسالة محادثة
              </li>
              <li className="flex gap-2 items-start">
                <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                القرآن والتلاوات مجاناً بالكامل
              </li>
            </ul>
            <Button
              variant="outline"
              className="w-full rounded-full"
              onClick={() => (user ? navigate("/chat") : navigate("/login"))}
            >
              {user ? "ابدأ المحادثة" : "سجّل مجاناً"}
            </Button>
          </CardContent>
        </Card>

        {PLANS.map((plan) => {
          const isCurrent = user?.plan === plan.id;
          return (
            <Card
              key={plan.id}
              className={`relative rounded-3xl shadow-sm overflow-hidden transition-all hover:shadow-lg ${
                plan.highlight
                  ? "border-islamic-600 ring-2 ring-islamic-500/40"
                  : "border-border/80"
              }`}
            >
              {plan.highlight && (
                <div className="absolute top-0 left-1/2 -translate-x-1/2 bg-gold-soft text-islamic-900 text-[11px] font-extrabold px-4 py-1 rounded-b-lg z-10">
                  الأكثر قيمة
                </div>
              )}
              <CardContent className={`p-6 ${plan.highlight ? "pt-8" : ""}`}>
                <h3 className="font-extrabold text-lg text-islamic-800 mb-1">{plan.name}</h3>
                <p className="text-3xl font-extrabold text-islamic-900 mb-4">
                  {plan.priceEgp}{" "}
                  <span className="text-sm font-semibold text-muted-foreground">جنيه</span>
                </p>
                <ul className="space-y-2.5 text-sm text-foreground/80 mb-6">
                  {plan.features.map((f, i) => (
                    <li key={i} className="flex gap-2 items-start">
                      <Check className="w-4 h-4 text-islamic-500 mt-0.5 shrink-0" />
                      {f}
                    </li>
                  ))}
                </ul>
                {isCurrent ? (
                  <Button variant="secondary" className="w-full rounded-full" disabled>
                    <BadgeCheck className="w-4 h-4 ml-1" />
                    باقتك الحالية
                  </Button>
                ) : (
                  <Button
                    className={`w-full rounded-full ${
                      plan.highlight
                        ? "bg-islamic-800 hover:bg-islamic-700"
                        : "bg-islamic-600 hover:bg-islamic-500"
                    }`}
                    onClick={() => {
                      if (!user) {
                        toast({
                          title: "سجّل الدخول أولاً",
                          description: "تحتاج حساباً لإرسال طلب اشتراك",
                        });
                        navigate("/login");
                        return;
                      }
                      setDialogPlan(plan);
                    }}
                  >
                    طلب اشتراك
                  </Button>
                )}
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* طلباتي */}
      {user && myRequests.length > 0 && (
        <section>
          <h2 className="text-xl font-extrabold text-islamic-800 mb-4">حالة طلباتي</h2>
          <div className="space-y-3">
            {myRequests.map((r) => {
              const meta = STATUS_META[r.status] ?? STATUS_META.PENDING;
              const Icon = meta.icon;
              const plan = getPlan(r.planId);
              return (
                <Card key={r.id} className="rounded-2xl border-border/70 shadow-sm">
                  <CardContent className="p-4 flex flex-wrap items-center gap-3">
                    <div
                      className={`w-10 h-10 rounded-xl border flex items-center justify-center shrink-0 ${meta.className}`}
                    >
                      <Icon className="w-5 h-5" />
                    </div>
                    <div className="flex-1 min-w-40">
                      <p className="font-bold text-sm text-islamic-900">
                        {plan?.name ?? r.planId} — {r.amount} جنيه
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {fmtDate(r.createdAt)} • {r.words} كلمة
                        {r.adminNote ? ` • ملاحظة الإدارة: ${r.adminNote}` : ""}
                      </p>
                    </div>
                    <Badge variant="outline" className={`text-[11px] ${meta.className}`}>
                      {meta.label}
                    </Badge>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </section>
      )}

      {/* شرح خطوات الدفع */}
      <section className="mt-10">
        <Card className="rounded-3xl border-gold-soft/50 bg-gradient-to-l from-gold-soft/10 to-white">
          <CardContent className="p-6 md:p-8">
            <h2 className="font-extrabold text-lg text-islamic-800 mb-4">
              كيف تتم عملية الاشتراك؟
            </h2>
            <div className="grid md:grid-cols-4 gap-4 text-sm">
              {[
                { n: "١", t: "اختر الباقة", d: "اضغط على باقتك المناسبة من الأعلى" },
                { n: "٢", t: "حوّل المبلغ", d: "عبر فودافون كاش أو إنستاباي أو غيرها" },
                { n: "٣", t: "أرسل الطلب", d: "أدخل رقم العملية أو ارفع صورة الإيصال" },
                { n: "٤", t: "التفعيل", d: "الإدارة تراجع وترصّد الرصيد فوراً بعد الموافقة" },
              ].map((s) => (
                <div key={s.n} className="flex gap-3 items-start">
                  <span className="w-8 h-8 shrink-0 rounded-full bg-islamic-800 text-white font-extrabold flex items-center justify-center text-sm">
                    {s.n}
                  </span>
                  <div>
                    <p className="font-bold text-islamic-900">{s.t}</p>
                    <p className="text-muted-foreground text-xs leading-6 mt-0.5">{s.d}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </section>

      {/* نافذة طلب الاشتراك */}
      <PaymentDialog
        plan={dialogPlan}
        open={!!dialogPlan}
        onClose={() => setDialogPlan(null)}
        onSuccess={() => {
          setDialogPlan(null);
          loadRequests();
        }}
      />
    </div>
  );
}

// ---------- نافذة الطلب ----------
function PaymentDialog({
  plan,
  open,
  onClose,
  onSuccess,
}: {
  plan: (typeof PLANS)[number] | null;
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}) {
  const user = useStore((s) => s.user);
  const { toast } = useToast();
  const [userName, setUserName] = useState("");
  const [phone, setPhone] = useState("");
  const [method, setMethod] = useState("vodafone_cash");
  const [ref, setRef] = useState("");
  const [receipt, setReceipt] = useState<{ dataUrl: string; name: string } | null>(null);
  const [submitting, setSubmitting] = useState(false);
  const fileRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (open && user) {
      setUserName(user.name);
      setPhone("");
      setRef("");
      setReceipt(null);
      setMethod("vodafone_cash");
    }
  }, [open, user]);

  const pickFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    if (!["image/jpeg", "image/png", "image/webp"].includes(file.type)) {
      toast({
        title: "نوع ملف غير مدعوم",
        description: "المسموح: صورة JPG أو PNG أو WEBP",
        variant: "destructive",
      });
      return;
    }
    if (file.size > 2 * 1024 * 1024) {
      toast({
        title: "حجم الصورة كبير",
        description: "الحد الأقصى ٢ ميجابايت",
        variant: "destructive",
      });
      return;
    }
    const reader = new FileReader();
    reader.onload = () => {
      setReceipt({ dataUrl: String(reader.result), name: file.name });
    };
    reader.readAsDataURL(file);
  };

  const submit = async () => {
    if (!plan) return;
    setSubmitting(true);
    try {
      const res = await fetch("/api/requests", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          planId: plan.id,
          userName,
          phone,
          paymentMethod: method,
          transactionRef: ref,
          receiptImage: receipt?.dataUrl ?? "",
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        toast({ title: "تعذّر إرسال الطلب", description: data.error, variant: "destructive" });
        return;
      }
      toast({
        title: "تم إرسال طلبك بنجاح",
        description: "سيتم مراجعته من الإدارة وإخبارك بالنتيجة قريباً",
      });
      onSuccess();
    } catch {
      toast({ title: "خطأ في الاتصال", variant: "destructive" });
    } finally {
      setSubmitting(false);
    }
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="rounded-3xl max-w-lg max-h-[90vh] overflow-y-auto">
        <DialogHeader className="text-right">
          <DialogTitle className="text-xl font-extrabold text-islamic-800">
            طلب اشتراك — {plan?.name}
          </DialogTitle>
          <DialogDescription>
            المبلغ: {plan?.priceEgp} جنيه مقابل {plan?.words} كلمة محادثة
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 pt-2">
          <div className="space-y-1.5">
            <Label htmlFor="pay-name">الاسم</Label>
            <Input
              id="pay-name"
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              placeholder="اسمك الكامل"
              className="rounded-xl"
            />
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pay-phone">رقم الموبايل</Label>
            <Input
              id="pay-phone"
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="01xxxxxxxxx"
              inputMode="tel"
              dir="ltr"
              className="rounded-xl text-right"
            />
          </div>

          <div className="space-y-1.5">
            <Label>طريقة الدفع</Label>
            <Select value={method} onValueChange={setMethod}>
              <SelectTrigger className="rounded-xl w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {PAYMENT_METHODS.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-1.5">
            <Label htmlFor="pay-ref">رقم العملية (اختياري إن أرفقت إيصالاً)</Label>
            <Input
              id="pay-ref"
              value={ref}
              onChange={(e) => setRef(e.target.value)}
              placeholder="مثال: TX-123456"
              dir="ltr"
              className="rounded-xl text-right"
            />
          </div>

          <div className="space-y-1.5">
            <Label>أو صورة الإيصال</Label>
            <input
              ref={fileRef}
              type="file"
              accept="image/jpeg,image/png,image/webp"
              className="hidden"
              onChange={pickFile}
            />
            {receipt ? (
              <div className="flex items-center gap-3 p-3 rounded-xl bg-islamic-50 border border-emerald-200">
                <ImageIcon className="w-5 h-5 text-islamic-600 shrink-0" />
                <span className="text-xs font-bold text-islamic-800 flex-1 truncate">
                  {receipt.name}
                </span>
                <button
                  onClick={() => setReceipt(null)}
                  className="text-muted-foreground hover:text-destructive"
                  aria-label="إزالة الصورة"
                >
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
            ) : (
              <button
                onClick={() => fileRef.current?.click()}
                className="w-full border-2 border-dashed border-border rounded-xl p-5 flex flex-col items-center gap-2 text-muted-foreground hover:border-islamic-400 hover:text-islamic-600 transition-colors"
              >
                <Upload className="w-6 h-6" />
                <span className="text-xs font-bold">ارفع صورة الإيصال (حتى ٢ ميجابايت)</span>
              </button>
            )}
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-3 text-xs text-amber-800 leading-6 flex gap-2">
            <FileText className="w-4 h-4 shrink-0 mt-0.5" />
            بعد إرسال الطلب سيصبح بحالة "بانتظار المراجعة"، وعند موافقة الإدارة
            يُفعّل اشتراكك ويضاف الرصيد لحسابك فوراً.
          </div>

          <Button
            onClick={submit}
            disabled={submitting || !userName.trim() || !phone.trim() || (!ref.trim() && !receipt)}
            className="w-full rounded-full bg-islamic-800 hover:bg-islamic-700 h-11"
          >
            {submitting ? (
              <span className="w-5 h-5 border-2 border-white/40 border-t-white rounded-full animate-spin" />
            ) : (
              <>
                <LogIn className="w-4 h-4 ml-1 -scale-x-100" />
                إرسال الطلب للإدارة
              </>
            )}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}
