"use client";

import { useEffect, useMemo, useState } from "react";
import { useStore, navigate } from "@/lib/store";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Search, Play, BookOpen, Headphones } from "lucide-react";

type Surah = {
  number: number;
  name: string;
  englishName: string;
  revelationType: string;
  numberOfAyahs: number;
};

// تطبيع بسيط للبحث في أسماء السور
function normalize(s: string): string {
  return s
    .replace(/[\u0610-\u061A\u064B-\u065F\u0670\u06D6-\u06ED\u08D3-\u08FF]/g, "")
    .replace(/[\u0622\u0623\u0625\u0671]/g, "\u0627")
    .replace(/\u0629/g, "\u0647")
    .replace(/\u0649/g, "\u064A")
    .trim();
}

export function QuranView() {
  const [surahs, setSurahs] = useState<Surah[]>([]);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");
  const player = useStore((s) => s.player);
  // آخر سورة محفوظة محلياً (قراءة واحدة عند أول عرض في المتصفح)
  const [lastSurah] = useState<number | null>(() => {
    if (typeof window === "undefined") return null;
    try {
      const last = parseInt(localStorage.getItem("ig_last_surah") || "", 10);
      return isNaN(last) ? null : last;
    } catch {
      return null;
    }
  });

  useEffect(() => {
    fetch("/api/quran/surahs")
      .then((r) => r.json())
      .then((d) => {
        setSurahs(d.surahs ?? []);
        setLoading(false);
      })
      .catch(() => setLoading(false));
  }, []);

  const filtered = useMemo(() => {
    const q = normalize(query);
    if (!q) return surahs;
    return surahs.filter(
      (s) =>
        normalize(s.name).includes(q) ||
        s.number.toString() === q ||
        s.englishName.toLowerCase().includes(query.toLowerCase().trim())
    );
  }, [surahs, query]);

  // السورة المطلوب متابعتها: المشغل الجاري إن وجد، وإلا آخر موضع محفوظ
  const followSurah = player.url ? player.surah : lastSurah;
  const lastSurahName = surahs.find((s) => s.number === followSurah)?.name;

  return (
    <div className="max-w-6xl mx-auto px-4 py-6 md:py-10">
      {/* العنوان */}
      <div className="flex items-center justify-between gap-4 mb-6">
        <div>
          <h1 className="text-2xl md:text-3xl font-extrabold text-islamic-800 flex items-center gap-2">
            <BookOpen className="w-7 h-7 text-islamic-600" />
            القرآن الكريم
          </h1>
          <p className="text-muted-foreground text-sm mt-1">
            ١١٤ سورة — نص عثماني وتلاوة بصوت من تختار
          </p>
        </div>
      </div>

      {/* متابعة الاستماع */}
      {followSurah && (
        <Card className="mb-6 rounded-2xl border-islamic-200 bg-gradient-to-l from-islamic-50 to-white shadow-sm">
          <CardContent className="p-4 flex items-center gap-3">
            <div className="w-10 h-10 rounded-full bg-islamic-800 text-white flex items-center justify-center shrink-0">
              <Headphones className="w-5 h-5" />
            </div>
            <div className="flex-1 min-w-0">
              <p className="font-bold text-sm text-islamic-800">
                متابعة الاستماع: سورة {lastSurahName ?? followSurah}
              </p>
              <p className="text-xs text-muted-foreground">
                أكمل من حيث توقفت في آخر زيارة
              </p>
            </div>
            <Button
              size="sm"
              className="rounded-full bg-islamic-800 hover:bg-islamic-700 gap-1"
              onClick={() => navigate(`/surah/${followSurah}`)}
            >
              <Play className="w-4 h-4" />
              متابعة
            </Button>
          </CardContent>
        </Card>
      )}

      {/* البحث */}
      <div className="relative mb-6">
        <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="ابحث باسم السورة أو رقمها… مثال: الكهف أو 18"
          className="pr-12 h-12 rounded-2xl bg-white border-border text-base"
          aria-label="بحث في السور"
        />
      </div>

      {/* القائمة */}
      {loading ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {Array.from({ length: 9 }).map((_, i) => (
            <Skeleton key={i} className="h-20 rounded-2xl" />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="text-center py-16 text-muted-foreground">
          <Search className="w-10 h-10 mx-auto mb-3 opacity-40" />
          <p className="font-bold">لا توجد نتائج لبحثك</p>
          <p className="text-sm mt-1">جرب اسماً آخر أو رقم سورة من ١ إلى ١١٤</p>
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
          {filtered.map((s) => (
            <button
              key={s.number}
              onClick={() => navigate(`/surah/${s.number}`)}
              className="text-right"
              aria-label={`سورة ${s.name}`}
            >
              <Card
                className={`rounded-2xl transition-all hover:shadow-md hover:-translate-y-0.5 hover:border-islamic-300 ${
                  player.surah === s.number && player.url
                    ? "border-islamic-500 bg-islamic-50"
                    : "border-border/70"
                }`}
              >
                <CardContent className="p-4 flex items-center gap-3">
                  <div className="relative w-11 h-11 shrink-0 flex items-center justify-center">
                    {/* إطار زخرفي لرقم السورة */}
                    <svg viewBox="0 0 44 44" className="absolute inset-0 w-full h-full text-islamic-200" aria-hidden="true">
                      <rect
                        x="4" y="4" width="36" height="36"
                        rx="10"
                        transform="rotate(45 22 22)"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="1.5"
                      />
                    </svg>
                    <span className="relative font-extrabold text-islamic-700 text-sm">
                      {s.number}
                    </span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-extrabold text-islamic-900 font-quran text-lg leading-tight">
                      {s.name}
                    </p>
                    <p className="text-[11px] text-muted-foreground mt-0.5">
                      {s.revelationType} • {s.numberOfAyahs} آية
                    </p>
                  </div>
                  <Play className="w-4 h-4 text-islamic-500 shrink-0" />
                </CardContent>
              </Card>
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
