import { PrismaClient } from '@prisma/client'
import { PrismaLibSQL } from '@prisma/adapter-libsql'

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

/**
 * Two runtime modes:
 * 1) TURSO_DATABASE_URL is set (Vercel / cloud) → connect to Turso (libSQL in the cloud)
 * 2) otherwise → local SQLite file (dev sandbox, VPS, Docker, Render, HF Spaces)
 *
 * Turso is SQLite-compatible, so the same schema works in both modes.
 */
function makePrisma(): PrismaClient {
  const tursoUrl = process.env.TURSO_DATABASE_URL
  if (tursoUrl) {
    // PrismaLibSQL is a driver factory: it creates the libSQL client internally
    const adapter = new PrismaLibSQL({
      url: tursoUrl,
      authToken: process.env.TURSO_AUTH_TOKEN || undefined,
    })
    return new PrismaClient({ adapter })
  }
  return new PrismaClient({
    log: process.env.NODE_ENV === 'production' ? [] : ['query'],
  })
}

export const db = globalForPrisma.prisma ?? makePrisma()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = db
