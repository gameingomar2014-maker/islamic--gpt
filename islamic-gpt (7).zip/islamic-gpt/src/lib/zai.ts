/**
 * Z.ai chat client — works everywhere (Vercel / VPS / Docker / dev sandbox).
 *
 * Credential resolution order:
 *   1) Environment variables:  ZAI_API_KEY (+ optional ZAI_BASE_URL, ZAI_MODEL)
 *   2) Config file .z-ai-config (cwd, home, /etc) — same file z-ai-web-dev-sdk uses
 *
 * The public Z.ai API is OpenAI-compatible: POST {baseUrl}/chat/completions
 */
export interface ChatMessageInput {
  role: "system" | "user" | "assistant";
  content: string;
}

interface CreateArgs {
  messages: ChatMessageInput[];
  thinking?: { type: "enabled" | "disabled" };
}

interface Config {
  baseUrl: string;
  apiKey: string;
  model?: string;
  // optional headers used by some Z.ai gateways (dev sandbox)
  chatId?: string;
  userId?: string;
  token?: string;
}

const DEFAULT_EXTERNAL_BASE_URL = "https://api.z.ai/api/paas/v4";

async function loadConfig(): Promise<Config> {
  // 1) Environment variables (recommended on any hosting)
  if (process.env.ZAI_API_KEY) {
    return {
      baseUrl: process.env.ZAI_BASE_URL || DEFAULT_EXTERNAL_BASE_URL,
      apiKey: process.env.ZAI_API_KEY,
      model: process.env.ZAI_MODEL, // optional; recommended on the public API
    };
  }

  // 2) Legacy config file (dev environments)
  const fs = await import("fs");
  const path = await import("path");
  const os = await import("os");
  const candidates = [
    path.join(process.cwd(), ".z-ai-config"),
    path.join(os.homedir(), ".z-ai-config"),
    "/etc/.z-ai-config",
  ];
  for (const p of candidates) {
    try {
      const cfg = JSON.parse(fs.readFileSync(p, "utf-8"));
      if (cfg?.baseUrl && cfg?.apiKey)
        return {
          baseUrl: cfg.baseUrl,
          apiKey: cfg.apiKey,
          chatId: cfg.chatId,
          userId: cfg.userId,
          token: cfg.token,
        };
    } catch {
      // keep looking
    }
  }

  throw new Error(
    "ZAI credentials not found. Set ZAI_API_KEY (and optionally ZAI_BASE_URL / ZAI_MODEL) in the environment."
  );
}

export const zai = {
  chat: {
    completions: {
      async create(args: CreateArgs) {
        const cfg = await loadConfig();
        const body: Record<string, unknown> = {
          messages: args.messages,
          thinking: args.thinking ?? { type: "disabled" },
        };
        // The sandbox internal API picks the model server-side; the public API
        // requires an explicit model name.
        if (cfg.model) body.model = cfg.model;

        const res = await fetch(`${cfg.baseUrl}/chat/completions`, {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
            Authorization: `Bearer ${cfg.apiKey}`,
            "X-Z-AI-From": "Z",
            ...(cfg.chatId ? { "X-Chat-Id": cfg.chatId } : {}),
            ...(cfg.userId ? { "X-User-Id": cfg.userId } : {}),
            ...(cfg.token ? { "X-Token": cfg.token } : {}),
          },
          body: JSON.stringify(body),
        });

        if (!res.ok) {
          const text = await res.text().catch(() => "");
          throw new Error(`ZAI API error ${res.status}: ${text.slice(0, 300)}`);
        }
        return (await res.json()) as {
          choices?: Array<{ message?: { content?: string } }>;
        };
      },
    },
  },
};
