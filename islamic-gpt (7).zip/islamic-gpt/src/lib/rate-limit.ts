// محدّد معدل الطلبات في الذاكرة (نافذة زمنية منزلقة بسيطة)

type Bucket = { count: number; resetAt: number };

const buckets = new Map<string, Bucket>();

// تنظيف دوري لتجنب تراكم الذاكرة
let lastCleanup = Date.now();
function cleanup(now: number) {
  if (now - lastCleanup < 60_000) return;
  lastCleanup = now;
  for (const [key, bucket] of buckets) {
    if (bucket.resetAt < now) buckets.delete(key);
  }
}

/**
 * يتحقق من السماح بالطلب. يُرجع true إذا مسموح.
 * @param key مفتاح فريد (مثال: "login:1.2.3.4:user@mail.com")
 * @param limit أقصى عدد محاولات في النافذة
 * @param windowMs حجم النافذة بالمللي ثانية
 */
export function rateLimit(
  key: string,
  limit: number,
  windowMs: number
): { allowed: boolean; retryAfterSec: number } {
  const now = Date.now();
  cleanup(now);
  const bucket = buckets.get(key);
  if (!bucket || bucket.resetAt < now) {
    buckets.set(key, { count: 1, resetAt: now + windowMs });
    return { allowed: true, retryAfterSec: 0 };
  }
  if (bucket.count >= limit) {
    return {
      allowed: false,
      retryAfterSec: Math.ceil((bucket.resetAt - now) / 1000),
    };
  }
  bucket.count += 1;
  return { allowed: true, retryAfterSec: 0 };
}

/**
 * تصفير عدّاد المحاولات لمفتاح معيّن (يُستدعى عند نجاح تسجيل الدخول
 * حتى لا تُحسب المحاولات الناجحة ضمن حد المحاولات الفاشلة)
 */
export function resetRateLimit(key: string): void {
  buckets.delete(key);
}

export function getClientIp(req: Request): string {
  const fwd = req.headers.get("x-forwarded-for");
  if (fwd) return fwd.split(",")[0].trim();
  return req.headers.get("x-real-ip") || "local";
}
