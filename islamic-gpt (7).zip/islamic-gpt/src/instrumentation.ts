/**
 * Next.js instrumentation — runs ONCE when the server starts (Node runtime).
 *
 * Purpose: on external hosting (Render / HF Spaces / Koyeb / VPS), the
 * z-ai-web-dev-sdk needs a `.z-ai-config` file containing { baseUrl, apiKey }.
 * The SDK looks for it in:  process.cwd()/.z-ai-config → ~/.z-ai-config → /etc/.z-ai-config
 *
 * To make deployment painless, we auto-generate the config file from env vars:
 *   ZAI_API_KEY   (required) — your Z.ai API key
 *   ZAI_BASE_URL  (optional) — defaults to https://api.z.ai/api/paas/v4
 *
 * If a config file already exists, or no ZAI_API_KEY is set, this is a no-op.
 */
export async function register() {
  if (process.env.NEXT_RUNTIME !== "nodejs") return;

  try {
    const fs = await import("fs");
    const path = await import("path");
    const os = await import("os");

    const candidates = [
      path.join(process.cwd(), ".z-ai-config"),
      path.join(os.homedir(), ".z-ai-config"),
      "/etc/.z-ai-config",
    ];

    // If any existing config is already present and valid, do nothing.
    for (const p of candidates) {
      try {
        const raw = fs.readFileSync(p, "utf-8");
        const cfg = JSON.parse(raw);
        if (cfg?.baseUrl && cfg?.apiKey) return; // already configured
      } catch {
        // file missing or invalid → keep looking
      }
    }

    const apiKey = process.env.ZAI_API_KEY;
    if (!apiKey) return; // no credentials provided → nothing to do

    const baseUrl = process.env.ZAI_BASE_URL || "https://api.z.ai/api/paas/v4";
    const config = {
      baseUrl,
      apiKey,
      ...(process.env.ZAI_CHAT_ID ? { chatId: process.env.ZAI_CHAT_ID } : {}),
    };

    const target = path.join(process.cwd(), ".z-ai-config");
    fs.writeFileSync(target, JSON.stringify(config, null, 2), { mode: 0o600 });
    console.log("[instrumentation] .z-ai-config created from environment variables");
  } catch (err) {
    console.error("[instrumentation] failed to prepare .z-ai-config:", err);
  }
}
